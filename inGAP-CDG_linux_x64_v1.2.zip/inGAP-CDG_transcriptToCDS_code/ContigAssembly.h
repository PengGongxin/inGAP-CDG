//
//  assembly.h
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_transcriptToCDS_assembly_h
#define openMP_libsvm_inGAP_CDG_transcriptToCDS_assembly_h

#include "graph.h"
#include "AssemblySubgraph.h"

class assembly {
public:
    assembly();
    virtual ~assembly();
    void DFSSubgraph (Graph &, int, int);
    void DFSSubgraphTraverse (Graph &);
    void GraphNodeArc (int,  char *);
    void ContigsAssembly (int, int, char *);
    void ContigsAssemblyStage(int, int,  char *);
};
#endif
