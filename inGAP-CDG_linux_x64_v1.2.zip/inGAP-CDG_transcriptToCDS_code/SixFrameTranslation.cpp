//
//  SixFrameTranslation.cpp
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//
#include "SixFrameTranslation.h"

vector<string> orf_seq_train;
vector<string> orf_seq_test;

SixFrameTranslation::SixFrameTranslation() {
    
}
SixFrameTranslation::~SixFrameTranslation() {
    
}
void SixFrameTranslation::Format_Infile(char *infile, char *outdir) {
    ifstream fin(infile);
    ofstream fout(string(outdir).append("/SixFrameTranslation/input.fa").c_str());
    ifstream fin1(string(outdir).append("/SixFrameTranslation/input.fa").c_str());
    ofstream fout1(string(outdir).append("/SixFrameTranslation/input.format.fa").c_str());
    string s, s1;
    int i=0;
    while (getline(fin, s, '\n')) {
        if (s == "")
            continue;
        if (s[0] == '>') {
            if(i >0)
                fout << "\n" << s << endl;
            else
                fout << s <<endl;
        }
        else
                fout << s;
        i++;
    }
    fout << endl;
    while(getline(fin1, s1, '\n')) {
        if (s1 == "")
            continue;
        string id = s1;
        id =s1;
        getline(fin1,s1,'\n');
        if (s1 != "" && s1.find("N") == string::npos)
            fout1 << id << "\n" << s1 << endl;
    }
    string command = "rm "+ string(outdir) + "/SixFrameTranslation/input.fa";
    const char *COMMAND= command.c_str();
    system(COMMAND);
    fin.close();
    fout.close();
    fin1.close();
    fout1.close();
}
string SixFrameTranslation::Reverse_complement(string s) {
    reverse(s.begin(), s.end());
    for (int i=0; i < s.length(); i++) {
        if (s[i] == 'A')
            s[i] = 'T';
        else if (s[i] == 'T')
            s[i] = 'A';
        else if (s[i] == 'C')
            s[i] = 'G';
        else if (s[i] == 'G')
            s[i] = 'C';
    }
    return s;
}
void SixFrameTranslation::Find_NucSeq(string s) {
    int j=0;
    vector<string> orf;
    while (j < 3) {
        string temp1 = Find_NucSeq_StopCodonsNum(s, j);
        if (temp1 != "")
            orf.push_back(temp1);
        string temp2 = Find_NucSeq_StopCodonsNum(Reverse_complement(s), j);
        if (temp2 != "")
            orf.push_back(temp2);
        j++;
    }
    if (orf.size() > 1)
        sort(orf.begin(), orf.end(), CMP_String_Length);
#pragma omp critical
    {
    if (orf.size() == 1) {
        orf_seq_train.push_back(orf[0]);
        orf_seq_test.push_back(orf[0]);
    }
    else if (orf.size() > 1){
        orf_seq_test.push_back(orf[0]);
        if (orf[1].length() >= 0.6*s.length())
            orf_seq_test.push_back(orf[1]);
    }
    }
}
void SixFrameTranslation::Find_NucSeq_long_reads(string s) {
    int j=0;
    vector<string> orf;
    while (j < 3) {
        orf.push_back(Find_NucSeq_StopCodonsNum_long_reads(s, j));
        orf.push_back(Find_NucSeq_StopCodonsNum_long_reads(Reverse_complement(s), j));
        j++;
    }
    if (orf.size() >1)
        sort(orf.begin(), orf.end(), CMP_String_Length);
#pragma omp critical
    {
    if (orf.size() == 1) {
        orf_seq_test.push_back(orf[0]);
        if (orf[0].length() >= 500)
            orf_seq_train.push_back(orf[0]);
    }
    else if (orf.size() > 1) {
        orf_seq_test.push_back(orf[0]);
        if (orf[0].length() >= 500)
            orf_seq_train.push_back(orf[0]);
        if (orf[1].length() >= 0.6*s.length())
            orf_seq_test.push_back(orf[1]);
    }
    }
}
string SixFrameTranslation::Find_NucSeq_StopCodonsNum(string s, int i) {
    string  nuc, temp = "";
    nuc = s.substr(i);
    if (NucTransPep(nuc).find('*') == string::npos)
        return nuc;
    else
        return temp;
}
string SixFrameTranslation::Find_NucSeq_StopCodonsNum_long_reads(string s , int i) {
    map<string,int> orf_candidate;
    string nuc, pep, orf_seq;
    nuc=s.substr(i);
    pep = NucTransPep(nuc);
    int count=0;
    if(pep.find('*')==string::npos)
        orf_seq = nuc;
    else {
        vector<int> position;
        for(int i=0;i<pep.length();i++) {
            if(pep[i]=='*') {
                position.push_back(i);
                count++;
            }
        }
        for(int i=0; i<position.size(); i++) {
            if (i==0)
                orf_candidate[nuc.substr(0,3*position[i])] = count;
            if (i==position.size()-1)
                orf_candidate[nuc.substr(3*(position[i]+1))] = count;
            if(0<i && i<position.size()-1)
                orf_candidate[nuc.substr(3*(position[i]+1),3*(position[i+1]-position[i]-1))] = count;
        }
        vector<string> orf_result;
        for(map<string, int>::iterator iter = orf_candidate.begin(); iter != orf_candidate.end(); ++iter)
            orf_result.push_back(iter->first);
        sort(orf_result.begin(), orf_result.end(), CMP_String_Length);
        orf_seq = orf_result[0];
    }
    return orf_seq;
}
void SixFrameTranslation::Find_Orf_length(string s) {
    if (s.length() >=500)
        Find_NucSeq_long_reads(s);
    else if (s.length() >=50)
        Find_NucSeq(s);
}
void SixFrameTranslation::SixFrameTranslationStage(char *infile, char *outdir, int threadnum) {
    string SixFrameTranslationDir = string(outdir).append("/SixFrameTranslation");
    mkdir(SixFrameTranslationDir.c_str(), 0755);
    Format_Infile(infile, outdir);
    ifstream fin(string(outdir).append("/SixFrameTranslation/input.format.fa").c_str());
    ofstream fout_graph_nuc(string(outdir).append("/SixFrameTranslation/graph.train.nuc").c_str());
    ofstream fout_graph_pep(string(outdir).append("/SixFrameTranslation/graph.train.pep").c_str());
    ofstream fout_test_nuc(string(outdir).append("/SixFrameTranslation/test.nuc").c_str());
    string s;
    vector <string> seq;
    while (getline(fin, s, '\n')) {
            if (s == "")
                continue;
            getline(fin, s, '\n');
            seq.push_back(s);
    }
#pragma omp parallel for num_threads(threadnum)
    for(int i=0; i< seq.size(); i++)
        Find_Orf_length(seq[i]);
    for (int i=0; i < orf_seq_train.size(); ++i) {
            string orf_seq_nuc = orf_seq_train[i];
            fout_graph_nuc << ">graph_nuc" << i << "\n" << orf_seq_nuc << endl;
            fout_graph_pep << ">graph_pep" << i << "\n" << NucTransPep(orf_seq_nuc) << endl;
    }
    for (int i=0; i < orf_seq_test.size(); ++i)
            fout_test_nuc << ">orf_test" << i << "\n" << orf_seq_test[i] << endl;
    vector<string>().swap(seq);
    vector<string>().swap(orf_seq_train);
    vector<string>().swap(orf_seq_test);
    fin.close();
    fout_graph_nuc.close();
    fout_graph_pep.close();
    fout_test_nuc.close();
}


