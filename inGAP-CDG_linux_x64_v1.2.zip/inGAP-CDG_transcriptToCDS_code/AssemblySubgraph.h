//
//  AssemblySubgraph.h
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_transcriptToCDS_AssemblySubgraph_h
#define openMP_libsvm_inGAP_CDG_transcriptToCDS_AssemblySubgraph_h

const int MaxVertexNum= 50000;
int Origin_subgraph_vertics_number;
set<int> Remove_vertics;
bool visited[MaxVertexNum];
vector<int> Simple_paths;
vector< vector<int> > Fragement_paths;
map<int, int> Origingraph_nodes_index_map_subgraph, Subgraph_nodes_index_map_origingraph;

struct SubGraph {
    VexNode vexs[MaxVertexNum];
    int vexnum;
    int arcnum;
};

bool GraphExsitArc(SubGraph &G, int i, int j) ;
void DeleteVex (SubGraph &G, int i);
void DeleteArc (SubGraph &G, int i, int j);
void InsertArc (SubGraph &G, int i, int j);
void FindPaths (SubGraph &G);
void FindContigs (SubGraph &G);
int SubgraphType (SubGraph &G);
void DFSSimplePath (SubGraph &G, int i);
void DFSSimplePathTraverse (SubGraph &G);
void DFSPaths (SubGraph &G, int v, bool visited[], int path[], int depth);
void DFSContigs (SubGraph &G, int v, bool visited[], int path[], int depth);
void RemoveTips (SubGraph &G, vector< vector<int> > path, int kmer_length, int tips_length);
void MergeBubbles (SubGraph &G, vector< vector<int> > path);
void PrintPaths (SubGraph &G, int path[], int length);
void PrintContigs (SubGraph &G, int path[], int length);

bool GraphExistArc (SubGraph &G, int i, int j) {
    ArcNode *p;
    p = G.vexs[i].firstarc;
    while (p && p->adjvex != j) {
        p = p->nextarc;
    }
    if(p)
        return true;
    else
        return false;
}
void DeleteVex (SubGraph &G, int i) {
    for(int j=0; j< Origin_subgraph_vertics_number; j++) {
        if (GraphExistArc(G, i, j))
            DeleteArc(G, i, j);
        if (GraphExistArc(G, j, i))
            DeleteArc(G, j, i);
    }
    G.vexnum--;
}
void DeleteArc (SubGraph &G, int i, int j) {
    ArcNode *p, *q;
    p=G.vexs[i].firstarc;
    if(p->adjvex==j) {
        G.vexs[i].firstarc=p->nextarc;
        free(p);
    }
    else {
        while (p->nextarc && p->nextarc->adjvex!=j)
            p=p->nextarc;
        if (p) {
            q=p->nextarc;
            p->nextarc=q->nextarc;
            free(q);
        }
    }
    G.vexs[i].outdegree--;
    G.vexs[j].indegree--;
    G.arcnum--;
}
void InsertArc (SubGraph &G, int i, int j) {
    ArcNode *p;
    p=new ArcNode;
    p->adjvex=j;
    p->nextarc=G.vexs[i].firstarc;
    G.vexs[i].firstarc=p;
    G.arcnum++;
}
void FindPaths(SubGraph &G) {
    int path[Origin_subgraph_vertics_number];
    memset(visited, false, sizeof(visited));
    for (int i=0; i<Origin_subgraph_vertics_number; i++) {
        if(!visited[i] && G.vexs[i].indegree==0) {
            visited[i]=true;
            path[0]=i;
            DFSPaths(G, i, visited, path, 1);
        }
    }
}
void FindContigs (SubGraph &G) {
    int path[Origin_subgraph_vertics_number];
    memset(visited, false, sizeof(visited));
    for (int i = 0; i < Origin_subgraph_vertics_number; i++) {
        if(!visited[i] && G.vexs[i].indegree==0) {
            visited[i]=true;
            path[0]=i;
            DFSContigs(G, i, visited, path, 1);
        }
    }
}
int SubgraphType (SubGraph &G) {
    int j = 0;
    if (G.vexnum-G.arcnum == 1) {
        int m=0,n=0;
        for (int i=0; i< G.vexnum; i++) {
            if (G.vexs[i].indegree <=1 && G.vexs[i].outdegree <= 1)
                m++;
            else
                n++;
        }
        if (n==0)
            j=1;
        else
            j=2;
    }
    else
        j=3;
    return j;
}
void DFSSimplePath (SubGraph &G, int i) {
    visited[i]=true;
    Simple_paths.push_back(i);
    ArcNode *p;
    for (p=G.vexs[i].firstarc; p!=NULL; p=p->nextarc) {
        if (visited[p->adjvex] == false) {
            DFSSimplePath(G, p->adjvex);
        }
    }
}
void DFSSimplePathTraverse (SubGraph &G) {
    int i;
    for (i=0; i < G.vexnum; i++) {
        visited[i]=0;
    }
    for (i=0; i < G.vexnum; i++) {
        if (G.vexs[i].indegree == 0)
            DFSSimplePath (G, i);
    }
}
void DFSPaths (SubGraph &G, int v, bool visited[], int path[], int depth) {
    for (ArcNode *arc=G.vexs[v].firstarc; arc!=NULL; arc=arc->nextarc) {
        if (G.vexs[arc->adjvex].outdegree>1 || G.vexs[arc->adjvex].indegree>1 || G.vexs[arc->adjvex].outdegree==0) {
            path[depth]=arc->adjvex;
            PrintPaths (G, path, depth+1);
        }
        if (!visited[arc->adjvex]) {
            visited[arc->adjvex]=true;
            path[depth]=arc->adjvex;
            DFSPaths(G, arc->adjvex, visited, path, depth+1);
        }
    }
}
void DFSContigs (SubGraph &G, int v, bool visited[], int path[], int depth) {
    for (ArcNode *arc=G.vexs[v].firstarc; arc!=NULL; arc=arc->nextarc) {
        if(G.vexs[arc->adjvex].outdegree==0){
            path[depth]=arc->adjvex;
            PrintContigs (G, path, depth+1);
        }
        if (!visited[arc->adjvex]) {
            visited[arc->adjvex]=true;
            path[depth]=arc->adjvex;
            DFSContigs(G, arc->adjvex, visited, path, depth+1);
        }
    }
}
void PrintPaths (SubGraph &G, int path[], int length) {
    vector<int> path_temp;
    for(int i=length-1; i>=0; i--) {
        path_temp.push_back(path[i]);
        if(i!=length-1 && (G.vexs[path[i]].outdegree>1|| G.vexs[path[i]].indegree>1))
            break;
    }
    reverse(path_temp.begin(), path_temp.end());
    Fragement_paths.push_back(path_temp);
}
void PrintContigs (SubGraph &G, int path[], int length) {
    vector<int> path_temp;
    for(int i=length-1; i>=0; i--) {
        path_temp.push_back(path[i]);
        if(i!=length-1 && G.vexs[path[i]].outdegree==0)
            break;
    }
    reverse(path_temp.begin(), path_temp.end());
    Fragement_paths.push_back(path_temp);
}
void RemoveTips (SubGraph &G, vector< vector<int> > path, int kmer_length, int tips_length) {
    vector < vector<int> > path_tips_one, path_tips_second;
    for (int i=0; i<path.size(); i++) {
        if (G.vexs[path[i][0]].outdegree>=2 && G.vexs[path[i][path[i].size()-1]].outdegree==0 && G.vexs[path[i].back()].indegree ==1)
            path_tips_one.push_back(path[i]);
        else if (G.vexs[path[i][0]].indegree==0 && G.vexs[path[i][0]].outdegree==1 && G.vexs[path[i][path[i].size()-1]].indegree>=2)
            path_tips_second.push_back(path[i]);
    }
    for(int i=0; i<path_tips_one.size(); i++) {
        vector< vector<int> > path_temp;
        for(int j=0; j<path_tips_one.size(); j++)
            if(path_tips_one[i][0]==path_tips_one[j][0])
                path_temp.push_back(path_tips_one[j]);
        if(path_temp.size()==1) {
            if(path_temp[0].size()<= tips_length -kmer_length)
                for(int i=1;i<path_temp[0].size(); i++)
                    Remove_vertics.insert(path_temp[0][i]);
        }
        else {
            sort(path_temp.begin(), path_temp.end(), CMP_Vector_Length);
            for (int p=0; p<path_temp.size(); p++) {
                if(path_temp[p].size()<= (tips_length - kmer_length)) {
                    if (p==0) {
                        if (G.vexs[path_temp[p][0]].outdegree==path_temp.size()) {
                            for(int i=p+1; i<path_temp.size(); i++)
                                for (int j=1; j<path_temp[i].size(); j++)
                                    Remove_vertics.insert(path_temp[i][j]);
                        }
                    }
                    else {
                        for(int i=p; i<path_temp.size(); i++)
                            for (int j=1; j<path_temp[i].size(); j++)
                                Remove_vertics.insert(path_temp[i][j]);
                    }
                }
            }
        }
        vector < vector<int> >().swap(path_temp);
    }
    for(int i=0; i<path_tips_second.size(); i++) {
        vector< vector<int> > path_temp;
        for(int j=0; j<path_tips_second.size(); j++) {
            if(path_tips_second[i][path_tips_second[i].size()-1]==path_tips_second[j][path_tips_second[j].size()-1])
                path_temp.push_back(path_tips_second[j]);
        }
        if(path_temp.size()==1) {
            if(path_temp[0].size()<= (tips_length - kmer_length))
                for(int i=0;i<path_temp[0].size()-1; i++)
                    Remove_vertics.insert(path_temp[0][i]);
        }
        else {
            sort(path_temp.begin(), path_temp.end(), CMP_Vector_Length);
            for (int p=0; p<path_temp.size(); p++) {
                if(path_temp[p].size()<= (tips_length - kmer_length)) {
                    if (p==0) {
                        if (G.vexs[path_temp[p][path_temp[p].size()-1]].indegree==path_temp.size()) {
                            for(int i=p+1; i<path_temp.size(); i++)
                                for (int j=0; j<path_temp[i].size()-1; j++)
                                    Remove_vertics.insert(path_temp[i][j]);
                        }
                    }
                    else {
                        for(int i=p; i<path_temp.size(); i++)
                            for (int j=0; j<path_temp[i].size()-1; j++)
                                Remove_vertics.insert(path_temp[i][j]);
                    }
                }
            }
        }
        vector < vector<int> >().swap(path_temp);
    }
    vector < vector<int> >().swap(path_tips_one);
    vector < vector<int> >().swap(path_tips_second);
}
void MergeBubbles (SubGraph &G, vector< vector<int> > path) {
    for(int i=0; i<path.size(); i++) {
        vector< vector<int> > path_temp;
        for(int j=0; j<path.size(); j++)
            if (G.vexs[path[i][0]].outdegree>1 && path[i][0]==path[j][0] && G.vexs[path[i][path[i].size()-1]].indegree>1 && path[i][path[i].size()-1]==path[j][path[j].size()-1])
                path_temp.push_back(path[j]);
        if(path_temp.size()>1) {
            sort(path_temp.begin(), path_temp.end(), CMP_Vector_Length);
            for(int i=1;i<path_temp.size();i++)
                for(int j=1; j<path_temp[i].size()-1; j++)
                    Remove_vertics.insert(path_temp[i][j]);
        }
    }
}

#endif
