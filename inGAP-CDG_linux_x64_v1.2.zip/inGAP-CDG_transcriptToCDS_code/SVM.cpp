//
//  svm.cpp
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#include "SVM.h"


vector< vector< vector<float> > > train_seq_svm;
map<int, vector<float> > test_seq_svm;

svm::svm() {
    
}
svm::~svm() {
    
}
int svm::Total_Freq(string s) {
    int total=0;
    for (int i=0; i < 64; i++)
        total += Freq(s, Codons[i]);
    return total;
}
int svm::Freq(string s, string codon) {
    vector<string> my_vector;
    for (int i=0; i < s.length()-2; i += 3)
        my_vector.push_back(s.substr(i, 3));
    int num= (int)count(my_vector.begin(), my_vector.end(), codon);
    return num;
}
void svm::SVM_Array(char *outdir, int trainlen, int testlen, int threadnum) {
    ifstream fin_train(string(outdir).append("/PreAssembly/precontigs.nuc.fas").c_str());
    ifstream fin_test(string(outdir).append("/SixFrameTranslation/test.nuc").c_str());
    ofstream fout_train_svm(string(outdir).append("/SVM/train.svm").c_str());
    ofstream fout_test_svm(string(outdir).append("/SVM/test.svm").c_str());
    string s_train, s_test;
    vector<string> train_seq;
    vector<string> test_seq;
    while (getline(fin_train, s_train, '\n')) {
        if (s_train =="")
            continue;
        getline(fin_train, s_train, '\n');
        if (s_train.length() >= trainlen)
            train_seq.push_back(s_train);
    }
    while (getline(fin_test, s_test, '\n')) {
        if (s_test == "")
            continue;
        getline(fin_test, s_test, '\n');
        if (s_test.length() >= testlen)
            test_seq.push_back(s_test);
    }
#pragma omp parallel for num_threads(threadnum)
    for (int i = 0; i < train_seq.size(); i++)
        SVM_Train(train_seq[i]);
    for (int i = 0; i < train_seq_svm.size(); i++) {
        for (int j=0; j < train_seq_svm[i].size(); j++) {
            if(j == 0)
                fout_train_svm << "1 ";
            if (j > 0)
                fout_train_svm << "-1 ";
            for (int z=0; z < train_seq_svm[i][j].size(); z++) {
                if (train_seq_svm[i][j][z] != 0)
                    fout_train_svm  << z+1 << ":" << train_seq_svm[i][j][z] << " ";
            }
            fout_train_svm << endl;
        }
    }
#pragma omp parallel for num_threads(threadnum)
    for (int i = 0; i < test_seq.size(); i++)
        SVM_Test(test_seq[i], i);
    for (map<int, vector<float> >::iterator iter = test_seq_svm.begin(); iter != test_seq_svm.end(); iter++) {
        fout_test_svm << "1 " ;
        for (int j=0; j < iter->second.size(); j++) {
            if (iter->second[j] != 0)
                fout_test_svm << j+1 << ":" <<iter->second[j] << " ";
        }
        fout_test_svm << endl;
    }
    vector<string>().swap(train_seq);
    vector<string>().swap(test_seq);
    vector< vector< vector<float> > >().swap(train_seq_svm);
    map<int, vector<float> >().swap(test_seq_svm);
    fout_train_svm.close();
    fout_test_svm.close();
}
void svm::SVM_Train(string s) {
    int j = 0;
    vector< vector<float> > train_svm;
    while (j < 3) {
        string s1_train, s2_train;
        vector<float> train1_svm, train2_svm;
        s1_train = s.substr(j);
        int total1 = Total_Freq(s1_train);
        for (int i=0; i < 64; i++)
            train1_svm.push_back((float)Freq(s1_train, Codons[i])/total1);
        train_svm.push_back(train1_svm);
        reverse(s.begin(), s.end());
        for (int p=0; p < s.length(); p++) {
            if (s[p] == 'A')
                s[p] = 'T';
            else if (s[p] == 'T')
                s[p] = 'A';
            else if (s[p] == 'C')
                s[p] = 'G';
            else if (s[p] == 'G')
                s[p] = 'C';
        }
        s2_train = s.substr(j);
        int total2 = Total_Freq(s2_train);
        for (int i =0; i < 64 ; i++)
            train2_svm.push_back((float)Freq(s2_train, Codons[i])/total2);
        train_svm.push_back(train2_svm);
        j++;
    }
#pragma omp critical
    train_seq_svm.push_back(train_svm);
    
}
void svm::SVM_Test(string s, int i) {
    vector<float> test_svm;
    int total = Total_Freq(s);
    for (int j =0; j < 64; j++)
        test_svm.push_back((float)Freq(s, Codons[j])/total);
#pragma omp critical
    test_seq_svm.insert(make_pair(i, test_svm));
}
void svm::SVM_LibSVM(char *outdir, string program_dir) {
    string lib_svm = program_dir+"libsvm-3.20";
    string out_dir = string(outdir);
    string grid_python_command = "python "+ lib_svm + "/tools/grid.py " + out_dir + "/SVM/train.svm | tail -n1 > " +out_dir + "/SVM/svm_best_para";
    const char *GRID_PYTHON_COMMAND= grid_python_command.c_str();
    system(GRID_PYTHON_COMMAND);
    string svm_best_para = string(outdir).append("/SVM/svm_best_para");
    ifstream fin(svm_best_para.c_str());
    string C,G,A,cost, gamma, accuary;
    while (fin >> C >> G >> A) {
        cost = C; gamma = G; accuary =A;
    }
    cout << accuary << endl;
    fin.close();
    string  svm_train_command = lib_svm + "/svm-train -c " + cost + " -g " + gamma + " -w1 0.1 -w-1 0.9 "+out_dir+"/SVM/train.svm  "+ out_dir + "/SVM/train.svm.model";
    const char *SVM_TRAIN_COMMAND = svm_train_command.c_str();
    system(SVM_TRAIN_COMMAND);
    string svm_predict_command = lib_svm + "/svm-predict "+ out_dir + "/SVM/test.svm " + out_dir + "/SVM/train.svm.model "+out_dir+"/SVM/svm.result";
    const char *SVM_PREDICT_COMMAND = svm_predict_command.c_str();
    system(SVM_PREDICT_COMMAND);
    
}
void svm::SVM_GetSeq(char *outdir, int svmdev) {
    ifstream fin_test_nuc(string(outdir).append("/SixFrameTranslation/test.nuc").c_str());
    ifstream fin_svm(string(outdir).append("/SVM/svm.result").c_str());
    ofstream fout_test_svm_nuc(string(outdir).append("/SVM/test.svm.nuc").c_str());
    map<int, vector<string> > test_nuc_map;
    vector<int> svm_vec;
    int index =0 ;
    float svm_result;
    while (fin_svm >> svm_result) {
        index++;
        if (svm_result >= svmdev)
            svm_vec.push_back(index);
    }
    int test_nuc_index =0;
    string nuc;
    while (getline(fin_test_nuc, nuc, '\n')) {
        if (nuc=="")
            continue;
        vector<string> test_nuc_vec;
        test_nuc_vec.push_back(nuc);
        getline(fin_test_nuc, nuc, '\n');
        test_nuc_vec.push_back(nuc);
        test_nuc_index++;
        test_nuc_map[test_nuc_index]=test_nuc_vec;
    }
    for (int i=0; i < svm_vec.size(); i++) {
        map<int, vector<string> >::iterator it = test_nuc_map.find(svm_vec[i]);
        if (it != test_nuc_map.end()) {
            fout_test_svm_nuc<< it->second[0] << endl;
            fout_test_svm_nuc << it->second[1] << endl;
        }
    }
    vector<int> ().swap(svm_vec);
    map<int, vector<string> >().swap(test_nuc_map);
    fin_test_nuc.close();
    fin_svm.close();
    fout_test_svm_nuc.close();
}
int svm::SVM(char *outdir, int trainlen, int testlen, int svmdev, int threadnum) {
    string SVMDir = string(outdir).append("/SVM");
    mkdir(SVMDir.c_str(), 0755);
    SVM_Array(outdir, trainlen, testlen, threadnum);
    cout << "Train and test array finished" <<endl;
    ifstream fin(string(outdir).append("/SVM/train.svm").c_str());
    string s_train;
    getline(fin,s_train);
    if (s_train=="") {
        cout << "Warning: ";
        cout << "the train length is longer. Please check the '-L' option." << endl;
        return 0;
    }
    string program_dir=get_program_dir();
    SVM_LibSVM(outdir, program_dir);
    SVM_GetSeq(outdir, svmdev);
    return 0;
}


