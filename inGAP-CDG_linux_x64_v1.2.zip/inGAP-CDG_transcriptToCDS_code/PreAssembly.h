//
//  preassembly.h
///  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#ifndef __openMP_libsvm_inGAP_CDG_transcriptToCDS__preassembly__
#define __openMP_libsvm_inGAP_CDG_transcriptToCDS__preassembly__

#include "graph.h"
#include "PreAssemblySubgraph.h"

class preassembly {
public:
    preassembly();
    virtual ~preassembly();
    void DFSPreGraph (Graph &, int, int);
    void DFSPreGraphTraverse (Graph &);
    void PreGraphNodeArc (int, char *);
    void PreAssemblyTrain (int, char *);
    void PreAssemblyStage(int, char *);
};


#endif /* defined(__openMP_SVM_inGAP-DB_denovo__preassembly__) */
