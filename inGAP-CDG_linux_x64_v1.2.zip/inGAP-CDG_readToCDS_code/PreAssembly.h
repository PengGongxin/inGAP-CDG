//
//  preassembly.h
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#ifndef __openMP_libsvm_inGAP_CDG_readToCDS__preassembly__
#define __openMP_libsvm_inGAP_CDG_readToCDS__preassembly__

#include "graph.h"
#include "PreAssemblySubgraph.h"

class preassembly {
public:
    preassembly();
    virtual ~preassembly();
    void DFSPreGraph (Graph &, int, int);
    void DFSPreGraphTraverse (Graph &);
    void PreGraphNodeArc (int, char *);
    void PreAssemblyTrain (int, char *);
    void PreAssemblyStage(int, char *);
};


#endif /* defined(__openMP_SVM_inGAP-DB_denovo__preassembly__) */
