//
//  svm.h
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#ifndef __openMP_libsvm_inGAP_CDG_readToCDS__svm__
#define __openMP_libsvm_inGAP_CDG_readToCDS__svm__

#include "common.h"

class svm {
public:
    svm();
    virtual ~svm();
    int Total_Freq(string);
    int Freq(string , string);
    void SVM_Array(char *, int, int, int);
    void SVM_Train(string);
    void SVM_Test(string, int i);
    void SVM_LibSVM(char *, string);
    void SVM_GetSeq(char *, int);
    int SVM(char *, int, int, int, int);
};

#endif /* defined(__openMP_SVM_inGAP_CDG_readToCDS__svm__) */
