//
//  main.cpp

//
//  Created by Peng Gongxin on 7/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <getopt.h>
#include <ctime>
#include "SixFrameTranslation.cpp"
#include "SVM.cpp"
#include "PreAssembly.cpp"
#include "ContigAssembly.cpp"
#include "ScaffoldAssembly.cpp"
#include "CDSAssembly.cpp"

void Usage();
int main(int argc, char * argv[]) {
    struct GlobalArgs_t {
        int threads_num;
        int stop_codons_num;
        int train_len;
        int potential_ORFs_cutoff;
        int svm_dev;
        int kmer_length;
        int subgraph_size;
        int tips_length;
        char *inFileName;
        char *outFileDir;
    } GlobalArgs;
    GlobalArgs.threads_num = 1;
    GlobalArgs.stop_codons_num = 0;
    GlobalArgs.train_len = 1000;
    GlobalArgs.potential_ORFs_cutoff = 1;
    GlobalArgs.svm_dev = 0;
    GlobalArgs.kmer_length = 27;
    GlobalArgs.subgraph_size = 300;
    GlobalArgs.tips_length = 2* GlobalArgs.kmer_length;
        //GlobalArgs.support_num = 5;
    while (1) {
        int opt, option_index=0;
        static const char *optString = "n:c:L:l:d:k:p:t:i:o:vh?";
        static struct option long_option[] = {
            {"threads_num ", required_argument, NULL, 'n' },
            {"stop_codons_num ", required_argument, NULL, 'c' },
            {"train_seq_len", required_argument, NULL, 'L' },
            {"potential_ORFs_cutoff", required_argument, NULL, 'l' },
                // {"libsvm", required_argument, NULL, 'a'},
                // {"blat", required_argument, NULL, 'b'},
            {"svm_dev", required_argument, NULL, 'd'},
            {"kmer", required_argument, NULL, 'k' },
            {"subgraph_size", required_argument, NULL, 'p' },
            {"tips_length", required_argument, NULL, 't' },
            {"input_file", required_argument, NULL, 'i' },
            { "output_dir", required_argument, NULL, 'o' },
            { "version", no_argument, NULL,'v' },
            { "help", no_argument, NULL, 'h'},
            { NULL, no_argument, NULL, 0 }
        };
        opt = getopt_long(argc, argv, optString, long_option, &option_index);
        if (opt == -1)
            break;
        switch (opt) {
            case 'n': GlobalArgs.threads_num = atoi(optarg); break;
            case 'c': GlobalArgs.stop_codons_num = atoi(optarg); break;
            case 'L': GlobalArgs.train_len = atoi(optarg); break;
            case 'l': GlobalArgs.potential_ORFs_cutoff = atoi(optarg); break;
                    //case 'a': GlobalArgs.libsvm = optarg; break;
                    //case 'b': GlobalArgs.blat = optarg; break;
            case 'd': GlobalArgs.svm_dev = atoi(optarg); break;
            case 'k': GlobalArgs.kmer_length = atoi(optarg); break;
            case 'p': GlobalArgs.subgraph_size = atoi(optarg); break;
            case 't': GlobalArgs.tips_length = atoi(optarg); break;
            case 'i': GlobalArgs.inFileName = optarg; break;
            case 'o': GlobalArgs.outFileDir = optarg; break;
            case 'v':
                cout << "inGAP-CDG version: 1.2\n";
                return 0;
                break;
            case 'h':
                Usage();
                return 0;
                break;
            case '?':
                cout <<"Try '-h' or '--help' for more information.\n";
                return 0;
                break;
            default:
                break;
        }
    }
    if (optind < argc  || argc <2) {
        cout << "Checking arguments. Try '-h' or '--help' for more information.\n";
        return 0;
    }
    fstream _file;
    _file.open(GlobalArgs.inFileName, ios::in);
    if(!_file) {
        cout << "Input file is not found. Please check the directory of input file.\n";
        return 0;
    }
    else
        cout << "Input file is found.\n";
    
    /*if (access(GlobalArgs.inFileName, 0)) {
        cout << "inputfile is not exsit!\n";
        return 0;
    }
    else
        cout << "inputfile is exsit!\n";
    */
    if (opendir(GlobalArgs.outFileDir) == NULL) {
        cout << "Output file directory is not found. It is created by inGAP-CDG. \n";
        mkdir(GlobalArgs.outFileDir,0755);
    }
    else
        cout << "Output file directory is found. \n";
        //clock_t starttime;
        //starttime = clock();
    GeneticCode();
    KmerInfo(GlobalArgs.kmer_length);
    SixFrameTranslation SixFrame;
    SixFrame.SixFrameTranslationStage(GlobalArgs.inFileName, GlobalArgs.outFileDir, GlobalArgs.threads_num);
    cout << "Six-frame translation finished."<< endl;
        //cout << "Used time: " << (double)(clock() - starttime)/CLOCKS_PER_SEC << "s" << endl;
    preassembly preassembly_train;
    preassembly_train.PreAssemblyStage(GlobalArgs.kmer_length, GlobalArgs.outFileDir);
    cout << "Preassembly finished." << endl;
        //cout << "Used time: " << (double)(clock() - starttime)/CLOCKS_PER_SEC << "s" << endl;
    svm svm_test;
    svm_test.SVM(GlobalArgs.outFileDir, GlobalArgs.train_len, GlobalArgs.potential_ORFs_cutoff,GlobalArgs.svm_dev, GlobalArgs.threads_num);
    cout << "SVM finished." << endl;
        //cout <<"Used time: " << (double)(clock() - starttime)/CLOCKS_PER_SEC << "s" << endl;
    assembly assembly_contigs;
    assembly_contigs.ContigsAssemblyStage(GlobalArgs.kmer_length, GlobalArgs.tips_length, GlobalArgs.outFileDir);
    cout << "Contigs assembly finished." << endl;
        //cout << "Used time: " << (double)(clock() - starttime)/CLOCKS_PER_SEC << "s" << endl;
    seedassembly assembly_scaffolds;
    assembly_scaffolds.ScaffoldsAssemblyStage(GlobalArgs.kmer_length, GlobalArgs.tips_length, GlobalArgs.subgraph_size, GlobalArgs.outFileDir);
    cout << "Scaffolds assembly finished." << endl;
        //cout << "Used time: " << (double)(clock() - starttime)/CLOCKS_PER_SEC << "s" << endl;
    cdsassembly assembly_cdss;
    assembly_cdss.cdsAssemblyStage(GlobalArgs.kmer_length, GlobalArgs.outFileDir);
    cout << "CDSs assembly finished." << endl;
        //cout << "Used time: " << (double)(clock() - starttime)/CLOCKS_PER_SEC << "s" << endl;
    return 0;
}

void Usage() {
    cout << "inGAP-CDG_readToCDS is a program which predicts gene from unassembled RNA-seq reads using codon-based de Bruijn graph .\n"
    "\n"
    "Usage: inGAP-CDG_readToCDS [OPTIONS]\n"
    "-i, --input_file             Please enter your input filename (in fasta format). [required] \n"
    "-o, --output_dir             Please enter your output directory filename. If not exists, the program will create it.\n"
    "-n, --threads_num            The thread number supported by openmp. [default: 1]\n"
     "\n"
    "-L, --train_seq_len          The minimal length of CDSs in positive data set for SVM. [default: 1000]\n"
    "-l, --potential_ORFs_cutoff  The potential ORFs that are larger than --potential_ORFs_cutoff*read_length will be kept. [default: 0.8]\n"
    "-d, --svm_dev                The SVM classification vector value to filter false positive ORFs. [default: 0] [-0.1, 0.1]\n"
     "\n"
    "-k, --kmer_length            The kmer size (a triple number) used to construct codon-based de Bruijn graph. [default: 27]\n"
    "-p, --subgraph_size          The minimal number of a subgraph nodes used to traverse. [default: 300]\n"
    "-t, --tips_length            The cutoff length of tips to be trimmed in de Bruijn graph. [default: 2*kmer_length]\n"
                                                                                

    "-h, --help                   Display this message then exit.\n"
    "\n"
    "Report bugs to email: penggongxin@biols.ac.cn\n";
}


