//
//  SixFrameTranslation.h
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_readToCDS_SixFrameTranslation_h
#define openMP_libsvm_inGAP_CDG_readToCDS_SixFrameTranslation_h

#include "common.h"

class SixFrameTranslation {
public:
    SixFrameTranslation();
    virtual ~SixFrameTranslation();
    void Format_Infile(char *, char *);
    string Reverse_complement(string);
    void Find_NucSeq(string);
    void Find_NucSeq_long_reads(string);
    void Find_Orf_length(string);
    string Find_NucSeq_StopCodonsNum(string, int);
    string Find_NucSeq_StopCodonsNum_long_reads(string, int);
    void SixFrameTranslationStage(char *, char *, int);
   
};


#endif
