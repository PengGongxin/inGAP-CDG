//
//  CDSAssembly.hpp
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 7/26/16.
//  Copyright © 2016 Peng Gongxin. All rights reserved.
//

#ifndef CDSAssembly_h
#define CDSAssembly_h

#include "graph.h"
#include "CDSAssemblySubgraph.h"
class cdsassembly {
public:
    cdsassembly();
    virtual ~cdsassembly();
    void DFScdsGraph (Graph &, int, int);
    void DFScdsGraphTraverse (Graph &);
    void cdsAssemblyBlat(char *, string);
    void cdsGraphNodeArc (int, char *);
    void cdsAssemblyTrain (int, char *);
    void cdsAssemblyFinal (char *, string);
    void cdsAssemblyStage(int, char *);
};



#endif /* CDSAssembly_h*/
