//
//  ScaffoldAssembly.h
//
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#ifndef __openMP_SVM_inGAP_CDG_readToCDS__ScaffoldAssembly__
#define __openMP_SVM_inGAP_CDG_readToCDS__ScaffoldAssembly__

#include "graph.h"
#include "AssemblySubgraph.h"

class seedassembly {
public:
    seedassembly();
    virtual ~seedassembly();
    void DFSORFSubgraph (Graph &, int, int);
    void DFSORFSubgraphTraverse (Graph &);
    void BFSORFSubgraphTraverse(Graph &);
    void ORFGraphNodeArc(int, char *);
    void SeedMarkerContigs(int, char *);
    int SubgraphNodesSeedMarker(vector< vector<int> >);
    bool ScaffoldsIdentify(vector<int>, int);
    string GetScaffoldsPaths(SubGraph &, vector<int>, int, int);
    void ScaffoldsAssembly (int, int, int, char *);
    void ScaffoldsAssemblyStage(int, int, int, char *);
};


#endif /* defined(__openMP_SVM_inGAP_DB_denovo__ScaffoldAssembly__) */
