//
//  ScaffoldAssembly.cpp
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#include "ScaffoldAssembly.h"
map<int, set<int> > ORFSubgraph_vertics;
vector<bool> orf_node_visited;
map<int, int> marker_node_link;
map<int, int> reverse_marker_node_link;
seedassembly::seedassembly() {
    
}
seedassembly::~seedassembly() {
    
}
void seedassembly::DFSORFSubgraph(Graph &G, int i, int subgraph_index) {
    orf_node_visited[i] = true;
    ORFSubgraph_vertics[subgraph_index].insert(i);
    ArcNode *p;
    for (p = G.vexs[i].firstarc; p != NULL; p = p->nextarc) {
        if (orf_node_visited[p->adjvex] == false)
            DFSORFSubgraph(G, p->adjvex, subgraph_index);
    }
}
void seedassembly::DFSORFSubgraphTraverse(Graph &G) {
    orf_node_visited.clear();
    for (int i = 0 ; i < G.vexnum; i++)
        orf_node_visited.push_back(false);
    int subgraph_index = 0;
    for (int i=0; i < G.vexnum; i++) {
        if (orf_node_visited[i] == false) {
            DFSORFSubgraph(G, i, subgraph_index);
            subgraph_index++;
        }
    }
}
void seedassembly::ORFGraphNodeArc(int kmer, char *outdir) {
    ifstream fin;
        //if (graph_type == "codon")
        fin.open(string(outdir).append("/SixFrameTranslation/test.nuc").c_str());
        // else if(graph_type == "peptide")
        // fin.open(string(outdir).append("/SixFrameTranslation/test.pep").c_str());
        //else
        //cout << "please check graph type\n";
    ofstream fout_kmer_info(string(outdir).append("/ScaffoldsAssembly/node.info").c_str());
    ofstream fout_arc(string(outdir).append("/ScaffoldsAssembly/arc").c_str());
    string buff;
    string s;
    map<string, int> kmer_cov;
    while (getline(fin, buff, '\n')) {
        getline(fin, buff, '\n');
            //if (graph_type == "codon") {
            for (int i=0; i < buff.length()-kmer+1; i+=3) {
                s = buff.substr(i, kmer);
                kmer_cov[s]++;
            }
            // }
            // else if (graph_type == "peptide") {
            //for (int i=0; i < buff.length()-kmer+1; i++) {
            //  s = buff.substr(i, kmer);
            //  kmer_cov[s]++;
            // }
            // }
    }
    multimap<string, vector<int> > node_index1, node_index2;
    int j = 0;
    for (map<string, int>::iterator kmer_cov_iter = kmer_cov.begin(); kmer_cov_iter != kmer_cov.end(); ++kmer_cov_iter) {
        if (kmer_cov_iter->second >= 2){// && kmer_cov_iter->second <=3500) {
            vector<int> kmer_info;
            kmer_info.push_back(j);
            kmer_info.push_back(kmer_cov_iter->second);
                // if (graph_type == "codon") {
                node_index1.insert(make_pair(kmer_cov_iter->first.substr(3), kmer_info));
                node_index2.insert(make_pair(kmer_cov_iter->first.substr(0,kmer-3), kmer_info));
                //}
                //else if (graph_type == "peptide") {
                // node_index1.insert(make_pair(kmer_cov_iter->first.substr(1), kmer_info));
                //node_index2.insert(make_pair(kmer_cov_iter->first.substr(0,kmer-1), kmer_info));
                //}
            fout_kmer_info << j << " " << kmer_cov_iter->first << " " << kmer_cov_iter->second <<endl;
            ++j;
            kmer_info.clear();
        }
    }
    map<string, int>().swap(kmer_cov);
    for (multimap<string, vector<int> >::iterator node_index1_iter = node_index1.begin() ; node_index1_iter != node_index1.end(); ) {
        multimap<string, vector<int> >::iterator node_index2_iter;
            node_index2_iter = node_index2.find(node_index1_iter->first);
        if (node_index2_iter != node_index2.end()) {
            unsigned long num = node_index2.count(node_index1_iter->first);
            for (int m=0; m < num; m++) {
                if (node_index1_iter->second[0] != node_index2_iter->second[0]) {
                       // if (node_index2_iter->second[1] >= node_index1_iter->second[1]  && node_index1_iter->second[1] >= 0.4*node_index2_iter->second[1])
                         //    fout_arc << node_index1_iter->second[0] << " " << node_index2_iter->second[0] << endl;
                         //else if (node_index2_iter->second[1] < node_index1_iter->second[1]  && node_index2_iter->second[1] >= 0.4*node_index1_iter->second[1])
                             fout_arc << node_index1_iter->second[0] << " " << node_index2_iter->second[0] << endl;
                }
                ++node_index2_iter;
            }
        }
        ++node_index1_iter;
    }
    multimap<string, vector<int> >().swap(node_index1);
    multimap<string, vector<int> >().swap(node_index2);
    fout_kmer_info.close();
    fout_arc.close();
}
void seedassembly::SeedMarkerContigs(int kmer, char *outdir) {
    ifstream fin_contigs, fin_orf_arc;
        //if (graph_type == "codon")
        fin_contigs.open(string(outdir).append("/ContigsAssembly/contigs.nuc.300.fas").c_str());
        //else if(graph_type == "peptide")
        //  fin_contigs.open(string(outdir).append("/ContigsAssembly/contigs.pep.300.fas").c_str());
    fin_orf_arc.open(string(outdir).append("/ScaffoldsAssembly/node.info").c_str());
    int orf_kmer_id;
        //cout << "ok" <<endl;
    string orf_kmer_seq;
    int orf_kmer_coverage;
    map<string, int> orf_kmer_info;
    while (fin_orf_arc >> orf_kmer_id >> orf_kmer_seq >> orf_kmer_coverage)
        orf_kmer_info.insert(make_pair(orf_kmer_seq, orf_kmer_id));
    string s, buff;
    while (getline(fin_contigs, buff, '\n')) {
        if (buff == "")
            continue;
        getline(fin_contigs, buff,'\n');
            // if (graph_type == "codon") {
            for (int i=0; i < buff.length()-kmer+1-3; i+=3) {
                string head = buff.substr(i, kmer);
                string tail = buff.substr(i+3,kmer);
                marker_node_link.insert(make_pair(orf_kmer_info[head], orf_kmer_info[tail]));
                reverse_marker_node_link.insert(make_pair(orf_kmer_info[tail], orf_kmer_info[head]));
            }
            // }
            //else if (graph_type == "peptide") {
            // for (int i=0; i < buff.length()-kmer; i++) {
            // string head = buff.substr(i, kmer);
            // string tail = buff.substr(i+1,kmer);
            // marker_node_link.insert(make_pair(orf_kmer_info[head], orf_kmer_info[tail]));
            //  reverse_marker_node_link.insert(make_pair(orf_kmer_info[tail], orf_kmer_info[head]));
            // }
                //}
    }
    map<string, int>().swap(orf_kmer_info);
    fin_contigs.close();
    fin_orf_arc.close();
}
int seedassembly::SubgraphNodesSeedMarker(vector< vector<int> > paths) {
    set<int> paths_nodes;
    for (int i =0 ; i < paths.size(); i++) {
        for (int j=0; j < paths[i].size(); j++) {
            paths_nodes.insert(marker_node_link[Subgraph_nodes_index_map_origingraph[paths[i][j]]]);
            paths_nodes.insert (reverse_marker_node_link[Subgraph_nodes_index_map_origingraph[paths[i][j]]]);
        }
    }
        //cout << paths_nodes.size() << endl;
    int num = int(paths_nodes.size());
    return num;
}
bool seedassembly::ScaffoldsIdentify(vector<int> path, int subgraph_marker_nodes_num) {
    set<int> paths_marker_node;
    for (int i=0; i < path.size(); i++ ){
        paths_marker_node.insert(marker_node_link[Subgraph_nodes_index_map_origingraph[path[i]]]);
        paths_marker_node.insert(reverse_marker_node_link[Subgraph_nodes_index_map_origingraph[path[i]]]);
    }
    int num = int(paths_marker_node.size());
    if (num >= 0.1*subgraph_marker_nodes_num)
        return true;
    else
        return false;
}
string seedassembly::GetScaffoldsPaths(SubGraph &G, vector<int> path, int num, int kmer) {
    string contigs_seq="";
    string temp_seq = "";
    if (ScaffoldsIdentify(path, num) == true) {
        for (int i=0; i < path.size(); i++) {
            if(i==0)
                contigs_seq = G.vexs[path[i]].kmer;
            if(i >0) {
                    //if (graph_type == "codon")
                    contigs_seq.append(G.vexs[path[i]].kmer.substr(kmer-3));
                    //else if (graph_type == "peptide")
                    //contigs_seq.append(G.vexs[path[i]].kmer.substr(kmer-1));
            }
        }
    }
    else {
        for (int i=0; i < path.size(); i++) {
            if(i==0)
                temp_seq = G.vexs[path[i]].kmer;
            if(i >0) {
                    // if (graph_type == "codon")
                    temp_seq.append(G.vexs[path[i]].kmer.substr(kmer-3));
                    //else if (graph_type == "peptide")
                    //temp_seq.append(G.vexs[path[i]].kmer.substr(kmer-1));
            }
        }
            if (temp_seq.length() >= 600)
                   contigs_seq = temp_seq;
            //if (graph_type == "peptide" && temp_seq.length() >= 200)
            // contigs_seq = temp_seq;
    }
    return contigs_seq;
}
void seedassembly::ScaffoldsAssembly(int kmer, int tips_len, int subgraph_size, char *outdir) {
    Graph Undirected_G, Directed_G, Reverse_G;
    CreateDirectedGraph_file(Directed_G, string(outdir).append("/ScaffoldsAssembly"));
    Reverse_G.vexnum = Directed_G.vexnum;
    Undirected_G.vexnum = Directed_G.vexnum;
    CreateReverseDirectedGraph_file(Reverse_G, string(outdir).append("/ScaffoldsAssembly"));
    CreateUndirectedGraph_file(Undirected_G, string(outdir).append("/ScaffoldsAssembly"));
    for (int i=0; i<Directed_G.vexnum; i++) {
        Directed_G.vexs[i].indegree=GetOutdegree(Reverse_G, i);
        Directed_G.vexs[i].outdegree=GetOutdegree(Directed_G, i);
    }
    ClearGraph(Reverse_G);
    DFSORFSubgraphTraverse(Undirected_G);
    ClearGraph(Undirected_G);
        //cout << ORFSubgraph_vertics.size() <<endl;
    ofstream fout;
        // if(graph_type == "codon") {
            //fout_origin.open(string(outdir).append("/ScaffoldsAssembly/scaffolds.nuc.fas").c_str());
        fout.open(string(outdir).append("/ScaffoldsAssembly/scaffolds.nuc.fas").c_str());
        // }
        //else if(graph_type == "peptide") {
            //fout_origin.open(string(outdir).append("/ScaffoldsAssembly/scaffolds.pep.fas").c_str());
            //fout.open(string(outdir).append("/ScaffoldsAssembly/scaffolds.pep.fas").c_str());
            //}
     int scaffold_number =1;
    for (int i = 0; i < ORFSubgraph_vertics.size(); i++){
            //cout << ORFSubgraph_vertics[i].size() <<endl;
       
        if (ORFSubgraph_vertics[i].size() <= 50000 && ORFSubgraph_vertics[i].size() >=subgraph_size) {
                //cout << ORFSubgraph_vertics[i].size() <<endl;
            Origingraph_nodes_index_map_subgraph.clear();
            Subgraph_nodes_index_map_origingraph.clear();
            int node_index=0;
            for (set<int>::iterator iter = ORFSubgraph_vertics[i].begin(); iter != ORFSubgraph_vertics[i].end(); iter++) {
                Origingraph_nodes_index_map_subgraph[*iter] = node_index;
                Subgraph_nodes_index_map_origingraph[node_index] = *iter;
                node_index++;
            }
            SubGraph G_subgraph;
            G_subgraph.vexnum = node_index;
            Origin_subgraph_vertics_number = node_index;
            for (int j=0; j<G_subgraph.vexnum; j++)
                G_subgraph.vexs[j].firstarc = NULL;
            G_subgraph.arcnum=0;
            for (map<int,int>::iterator iter=Origingraph_nodes_index_map_subgraph.begin(); iter!=Origingraph_nodes_index_map_subgraph.end(); iter++) {
                G_subgraph.vexs[iter->second].indegree = Directed_G.vexs[iter->first].indegree;
                G_subgraph.vexs[iter->second].outdegree = Directed_G.vexs[iter->first].outdegree;
                G_subgraph.vexs[iter->second].kmer = Directed_G.vexs[iter->first].kmer;
                ArcNode *p;
                p=Directed_G.vexs[iter->first].firstarc;
                while (p!=NULL) {
                    InsertArc(G_subgraph, iter->second, Origingraph_nodes_index_map_subgraph[p->adjvex]);
                    p=p->nextarc;
                }
            }
            if (SubgraphType(G_subgraph)==1) {
                Simple_paths.clear();
                DFSSimplePathTraverse(G_subgraph);
                string contigs_id = ">scaffold" + int2string(scaffold_number);
                string contigs_seq;
                for (int j=0; j<Simple_paths.size(); j++) {
                    if (j==0)
                        contigs_seq = G_subgraph.vexs[Simple_paths[j]].kmer;
                    if(j>0) {
                            //if (graph_type == "codon")
                            contigs_seq.append(G_subgraph.vexs[Simple_paths[j]].kmer.substr(kmer-3));
                            //else if (graph_type == "peptide")
                            //  contigs_seq.append(G_subgraph.vexs[Simple_paths[j]].kmer.substr(kmer-1));
                    }
                }
                fout << contigs_id << "\n" << contigs_seq <<endl;
            }
            if (SubgraphType(G_subgraph)==2) {
                Fragement_paths.clear();
                FindPaths(G_subgraph);
                RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                while (Remove_vertics.size()) {
                    for (set <int>::iterator iter=Remove_vertics.begin(); iter!=Remove_vertics.end(); iter++)
                        DeleteVex(G_subgraph, *iter);
                    Remove_vertics.clear();
                    Fragement_paths.clear();
                    FindPaths(G_subgraph);
                    RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                }
                Fragement_paths.clear();
                FindContigs(G_subgraph);
                sort(Fragement_paths.begin(), Fragement_paths.end(), CMP_Vector_Length);
                int num = SubgraphNodesSeedMarker(Fragement_paths);
                vector<string> contigs;
                for(int paths_num=0; paths_num < Fragement_paths.size(); paths_num++) {
                    string scaffold_seq=GetScaffoldsPaths(G_subgraph, Fragement_paths[paths_num], num, kmer);
                    if(scaffold_seq != "")
                        contigs.push_back(scaffold_seq);
                }
                if (contigs.size() >0)
                fout <<">scaffold" << scaffold_number<< "\n" << contigs[0] << "\n";
            }
            if (SubgraphType(G_subgraph)==3) {
                Fragement_paths.clear();
                FindPaths(G_subgraph);
                RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                MergeBubbles(G_subgraph, Fragement_paths);
                while (Remove_vertics.size()) {
                    for (set <int>::iterator iter=Remove_vertics.begin(); iter!=Remove_vertics.end(); iter++)
                        DeleteVex(G_subgraph, *iter);
                    Remove_vertics.clear();
                    Fragement_paths.clear();
                    FindPaths(G_subgraph);
                    RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                    MergeBubbles(G_subgraph, Fragement_paths);
                }
                Fragement_paths.clear();
                FindContigs(G_subgraph);
                sort(Fragement_paths.begin(), Fragement_paths.end(), CMP_Vector_Length);
                int num = SubgraphNodesSeedMarker(Fragement_paths);
                vector<string> contigs;
                for(int paths_num=0; paths_num < Fragement_paths.size(); paths_num++) {
                    string scaffold_seq=GetScaffoldsPaths(G_subgraph, Fragement_paths[paths_num], num, kmer);
                    if(scaffold_seq != "")
                        contigs.push_back(scaffold_seq);
                }
               if(contigs.size() > 0)
                fout <<">scaffold" << scaffold_number<< "\n" << contigs[0] << "\n";
            }
            scaffold_number++;
        }
    }
    map<int, set<int> >().swap(ORFSubgraph_vertics);
    ClearGraph(Directed_G);
        //fout_origin.close();
    fout.close();
    
}
void seedassembly::ScaffoldsAssemblyStage(int kmer, int tips_len, int subgraph_size, char *outdir) {
    string ScaffoldsAssemblyDir = string(outdir).append("/ScaffoldsAssembly");
    mkdir(ScaffoldsAssemblyDir.c_str(), 0755);
        //string OutputCDSsDir = string(outdir).append("/OutputCDSs");
        //mkdir(OutputCDSsDir.c_str(), 0755);
    ORFGraphNodeArc(kmer,outdir);
    SeedMarkerContigs(kmer, outdir);
    ScaffoldsAssembly(kmer, tips_len, subgraph_size, outdir);
}
