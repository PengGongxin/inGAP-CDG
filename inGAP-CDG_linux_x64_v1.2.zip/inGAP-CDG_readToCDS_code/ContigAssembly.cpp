//
//  assembly.cpp
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#include "ContigAssembly.h"

map<int, set<int> > Subgraph_vertics;
vector<bool> node_visited;
assembly::assembly() {
    
}
assembly::~assembly() {
    
}
void assembly::DFSSubgraph(Graph &G, int i, int subgraph_index) {
    node_visited[i] = true;
    Subgraph_vertics[subgraph_index].insert(i);
    ArcNode *p;
    for (p = G.vexs[i].firstarc; p != NULL; p = p->nextarc) {
        if (node_visited[p->adjvex] == false)
            DFSSubgraph(G, p->adjvex, subgraph_index);
    }
}
void assembly::DFSSubgraphTraverse(Graph &G) {
    node_visited.clear();
    for (int i = 0 ; i < G.vexnum; i++)
       node_visited.push_back(false);
    int subgraph_index = 0;
    for (int i=0; i < G.vexnum; i++) {
        if (node_visited[i] == false) {
            DFSSubgraph(G, i, subgraph_index);
            subgraph_index++;
        }
    }
}
void assembly::GraphNodeArc(int kmer, char *outdir) {
    ifstream fin;
        //if (graph_type == "codon")
        fin.open(string(outdir).append("/SVM/test.svm.nuc").c_str());
        //else if(graph_type == "peptide")
        //fin.open(string(outdir).append("/SVM/test.svm.pep").c_str());
        //else
        //cout << "please check graph type\n";
    ofstream fout_kmer_info(string(outdir).append("/ContigsAssembly/node.info").c_str());
    ofstream fout_arc(string(outdir).append("/ContigsAssembly/arc").c_str());
    string buff;
    string s;
    map<string, int> kmer_cov, node_index;
    multimap<string, int> node_index1, node_index2;
    while (getline(fin, buff, '\n')) {
        getline(fin, buff, '\n');
            // if (graph_type == "codon") {
            for (int i=0; i < buff.length()-kmer+1; i+=3) {
                s = buff.substr(i, kmer);
                kmer_cov[s]++;
            }
            //}
            //else if (graph_type == "peptide") {
            //for (int i=0; i < buff.length()-kmer+1; i++) {
            //  s = buff.substr(i, kmer);
            // kmer_cov[s]++;
            //}
            //}
    }
    int j = 0;
    for (map<string, int>::iterator kmer_cov_iter = kmer_cov.begin(); kmer_cov_iter != kmer_cov.end(); ++kmer_cov_iter) {
        if (kmer_cov_iter->second >= 2) {
          node_index[kmer_cov_iter->first] = j;
                //if (graph_type == "codon") {
              node_index1.insert(make_pair(kmer_cov_iter->first.substr(3), j));
              node_index2.insert(make_pair(kmer_cov_iter->first.substr(0,kmer-3), j));
                //}
                // else if (graph_type == "peptide") {
                //node_index1.insert(make_pair(kmer_cov_iter->first.substr(1), j));
                //node_index2.insert(make_pair(kmer_cov_iter->first.substr(0,kmer-1), j));
                //}
                // vector<string> kmer_info;
                //kmer_info.push_back(kmer_cov_iter->first);
                //kmer_info.push_back(int2string(kmer_cov_iter->second));
          fout_kmer_info << j << " " << kmer_cov_iter->first << " " << kmer_cov_iter->second <<endl;
          ++j;
                //kmer_info.clear();
        }
    }
    map<string, int>().swap(kmer_cov);
    map<string, int>().swap(node_index);
    for (multimap<string, int>::iterator node_index1_iter = node_index1.begin() ; node_index1_iter != node_index1.end(); ) {
        multimap<string, int>::iterator node_index2_iter = node_index2.find(node_index1_iter->first);
        if (node_index2_iter != node_index2.end()) {
            unsigned long num = node_index2.count(node_index1_iter->first);
            for (int m=0; m < num; m++) {
                if (node_index1_iter->second != node_index2_iter->second)
                    fout_arc << node_index1_iter->second << " " << node_index2_iter->second << endl;
                ++node_index2_iter;
            }
        }
        ++node_index1_iter;
    }
    multimap<string, int>().swap(node_index1);
    multimap<string, int>().swap(node_index2);
    fout_kmer_info.close();
    fout_arc.close();
}
void assembly::ContigsAssembly(int kmer, int tips_len,  char *outdir) {
    Graph Undirected_G, Directed_G, Reverse_G;
    CreateDirectedGraph_file(Directed_G, string(outdir).append("/ContigsAssembly"));
    Reverse_G.vexnum = Directed_G.vexnum;
    Undirected_G.vexnum = Directed_G.vexnum;
    CreateReverseDirectedGraph_file(Reverse_G, string(outdir).append("/ContigsAssembly"));
    CreateUndirectedGraph_file(Undirected_G, string(outdir).append("/ContigsAssembly"));
    for (int i=0; i<Directed_G.vexnum; i++) {
        Directed_G.vexs[i].indegree=GetOutdegree(Reverse_G, i);
        Directed_G.vexs[i].outdegree=GetOutdegree(Directed_G, i);
    }
    ClearGraph(Reverse_G);
    DFSSubgraphTraverse(Undirected_G);
    ClearGraph(Undirected_G);
    cout << Subgraph_vertics.size() <<endl;
    ofstream fout;
        //if(graph_type == "codon")
        fout.open(string(outdir).append("/ContigsAssembly/contigs.nuc.fas").c_str());
        //else if(graph_type == "peptide")
        // fout.open(string(outdir).append("/ContigsAssembly/contigs.pep.fas").c_str());
    for (int i = 0; i < Subgraph_vertics.size(); i++) {
        if (Subgraph_vertics[i].size() <= 50000) {
//            cout << Subgraph_vertics[i].size() <<endl;
            Origingraph_nodes_index_map_subgraph.clear();
            Subgraph_nodes_index_map_origingraph.clear();
            int node_index=0;
            for (set<int>::iterator iter=Subgraph_vertics[i].begin(); iter!=Subgraph_vertics[i].end(); iter++) {
                Origingraph_nodes_index_map_subgraph[*iter] = node_index;
                Subgraph_nodes_index_map_origingraph[node_index] = *iter;
                node_index++;
            }
            SubGraph G_subgraph;
            G_subgraph.vexnum = node_index;
            Origin_subgraph_vertics_number = node_index;
            for (int j=0; j<G_subgraph.vexnum; j++)
                G_subgraph.vexs[j].firstarc = NULL;
            G_subgraph.arcnum=0;
            for (map<int,int>::iterator iter=Origingraph_nodes_index_map_subgraph.begin(); iter!=Origingraph_nodes_index_map_subgraph.end(); iter++) {
                G_subgraph.vexs[iter->second].indegree = Directed_G.vexs[iter->first].indegree;
                G_subgraph.vexs[iter->second].outdegree = Directed_G.vexs[iter->first].outdegree;
                G_subgraph.vexs[iter->second].kmer = Directed_G.vexs[iter->first].kmer;
                ArcNode *p;
                p=Directed_G.vexs[iter->first].firstarc;
                while (p!=NULL) {
                    InsertArc(G_subgraph, iter->second, Origingraph_nodes_index_map_subgraph[p->adjvex]);
                    p=p->nextarc;
                }
            }
  //          cout << "subgraph basic info: "<< G_subgraph.vexnum << " " << G_subgraph.arcnum << endl;
            if (SubgraphType(G_subgraph)==1) {
                Simple_paths.clear();
                DFSSimplePathTraverse(G_subgraph);
                string contigs_id = ">contig" + int2string(i+1) +  " simple";
                string contigs_seq;
                for (int j=0; j<Simple_paths.size(); j++) {
                    if (j==0)
                        contigs_seq = G_subgraph.vexs[Simple_paths[j]].kmer;
                    if(j>0) {
                            // if (graph_type == "codon")
                            contigs_seq.append(G_subgraph.vexs[Simple_paths[j]].kmer.substr(kmer-3));
                            //else if (graph_type == "peptide")
                            // contigs_seq.append(G_subgraph.vexs[Simple_paths[j]].kmer.substr(kmer-1));
                    }
                }
                fout << contigs_id << "\n" << contigs_seq <<endl;
            }
            if (SubgraphType(G_subgraph)==2) {
                Fragement_paths.clear();
                FindPaths(G_subgraph);
                RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                while (Remove_vertics.size()) {
                    for (set <int>::iterator iter=Remove_vertics.begin(); iter!=Remove_vertics.end(); iter++)
                        DeleteVex(G_subgraph, *iter);
                    Remove_vertics.clear();
                    Fragement_paths.clear();
                    FindPaths(G_subgraph);
                    RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                }
                Fragement_paths.clear();
                FindContigs(G_subgraph);
                vector <string> contigs;
                for (int m=0; m<Fragement_paths.size(); m++) {
                    string contigs_seq;
                    for (int j=0; j<Fragement_paths[m].size(); j++) {
                        if(j==0)
                            contigs_seq = G_subgraph.vexs[Fragement_paths[m][j]].kmer;
                        if(j>0) {
                                // if (graph_type == "codon")
                                contigs_seq.append(G_subgraph.vexs[Fragement_paths[m][j]].kmer.substr(kmer-3));
                                // else if (graph_type == "peptide")
                                // contigs_seq.append(G_subgraph.vexs[Fragement_paths[m][j]].kmer.substr(kmer-1));
                        }
                    }
                    contigs.push_back(contigs_seq);
                }
                if (contigs.size() >=2)
                     sort(contigs.begin(), contigs.end(), CMP_String_Length);
                 if (contigs.size() >=1)
                     fout <<">contigs" << i+1 << "_tips\n" << contigs[0] << "\n";
            }
            if (SubgraphType(G_subgraph)==3) {
                Fragement_paths.clear();
                FindPaths(G_subgraph);
                RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                MergeBubbles(G_subgraph, Fragement_paths);
                while (Remove_vertics.size()) {
                    for (set <int>::iterator iter=Remove_vertics.begin(); iter!=Remove_vertics.end(); iter++)
                        DeleteVex(G_subgraph, *iter);
                    Remove_vertics.clear();
                    Fragement_paths.clear();
                    FindPaths(G_subgraph);
                    RemoveTips(G_subgraph, Fragement_paths, kmer, tips_len);
                    MergeBubbles(G_subgraph, Fragement_paths);
                }
                Fragement_paths.clear();
                FindContigs(G_subgraph);
                vector <string> contigs;
                for (int m=0; m<Fragement_paths.size(); m++) {
                        //string contigs_id = ">contigs" + int2string(i+1) +"_"+int2string(m+1)+" tips_bubbles_or_bubbles" ;
                    string contigs_seq;
                    for (int j=0; j<Fragement_paths[m].size(); j++) {
                        if(j==0)
                            contigs_seq = G_subgraph.vexs[Fragement_paths[m][j]].kmer;
                        if(j>0) {
                                //if (graph_type == "codon")
                                contigs_seq.append(G_subgraph.vexs[Fragement_paths[m][j]].kmer.substr(kmer-3));
                                // else if (graph_type == "peptide")
                                // contigs_seq.append(G_subgraph.vexs[Fragement_paths[m][j]].kmer.substr(kmer-1));
                        }
                       contigs.push_back(contigs_seq);
                    }
                }
                 if (contigs.size() >=2)
                     sort(contigs.begin(), contigs.end(), CMP_String_Length);
                if (contigs.size() >=1)
                    fout<<">contigs" << i+1 <<"_tips_bubbles\n" << contigs[0] << "\n";
            }
      }
    }
        // if (graph_type == "codon") {
        ifstream fin(string(outdir).append("/ContigsAssembly/contigs.nuc.fas").c_str());
        ofstream fout_nuc_300(string(outdir).append("/ContigsAssembly/contigs.nuc.300.fas").c_str());
        ofstream fout_pep(string(outdir).append("/ContigsAssembly/contigs.pep.fas").c_str());
        ofstream fout_pep_100(string(outdir).append("/ContigsAssembly/contigs.pep.100.fas").c_str());
        string s;
        while (getline(fin, s, '\n')) {
            string id, seq, pep;
            if(s=="")
                continue;
            id = s;
            getline(fin,s,'\n');
            if (s.length() >= 300) {
                fout_nuc_300 << id << endl;
                fout_nuc_300 << s << endl;
            }
            for(int i=0; i<s.length()-2; i+=3)
                pep.append(GeneticCodeTable[s.substr(i, 3)]);
            fout_pep << id << endl;
            fout_pep << pep << endl;
            if (pep.length() >= 100) {
                fout_pep_100 << id << endl;
                fout_pep_100 << pep << endl;
            }
                //}
        fin.close();
        fout_pep.close();
        fout_nuc_300.close();
        fout_pep_100.close();
    }
    map<int, set<int> >().swap(Subgraph_vertics);
    ClearGraph(Directed_G);
}
void assembly::ContigsAssemblyStage(int kmer, int tips_len, char *outdir) {
    string ContigsAssemblyDir = string(outdir).append("/ContigsAssembly");
    mkdir(ContigsAssemblyDir.c_str(), 0755);
    GraphNodeArc(kmer,outdir);
    ContigsAssembly(kmer, tips_len, outdir);
}

