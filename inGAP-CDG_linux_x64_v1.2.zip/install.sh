g++ ./inGAP-CDG_readToCDS_code/main.cpp -o inGAP-CDG_readToCDS -fopenmp
g++ ./inGAP-CDG_transcriptToCDS_code/main.cpp -o inGAP-CDG_transcriptToCDS -fopenmp
