g++ ./inGAP-CDG_readToCDS_code/main.cpp -o inGAP-CDG_readToCDS 
g++ ./inGAP-CDG_transcriptToCDS_code/main.cpp -o inGAP-CDG_transcriptToCDS 
