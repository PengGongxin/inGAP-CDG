//
//  PreAssemblySubgraph.h
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_transcriptToCDS_PreAssemblySubgraph_h
#define openMP_libsvm_inGAP_CDG_transcriptToCDS_PreAssemblySubgraph_h

const int Max_PreSubgraph_VertexNum= 50000;
int Origin_presubgraph_vertics_number;
bool presubgraphvisited[Max_PreSubgraph_VertexNum];
vector< vector<int> > PreFragement_paths;
map<int, int> pregraph_nodes_map_presubgraph, presubgraph_nodes_map_pregraph;

struct PreSubGraph {
    VexNode vexs[Max_PreSubgraph_VertexNum];
    int vexnum;
    int arcnum;
};


void FindPreContigs (PreSubGraph &G);
void InsertPreArc (PreSubGraph &G, int i, int j);
void DFSPreContigs (PreSubGraph &G, int v, bool presubgraphvisited[], int path[], int depth);
void PrintPreContigs (PreSubGraph &G, int path[], int length);

void InsertPreArc (PreSubGraph &G, int i, int j) {
    ArcNode *p;
    p=new ArcNode;
    p->adjvex=j;
    p->nextarc=G.vexs[i].firstarc;
    G.vexs[i].firstarc=p;
    G.arcnum++;
        //cout << G.arcnum <<endl;
}
void FindPreContigs (PreSubGraph &G) {
    int path[Origin_presubgraph_vertics_number];
    memset(presubgraphvisited, false, sizeof(presubgraphvisited));
    for (int i = 0; i < Origin_presubgraph_vertics_number; i++) {
        if(!presubgraphvisited[i] && G.vexs[i].indegree==0) {
            presubgraphvisited[i]=true;
            path[0]=i;
            DFSPreContigs(G, i, presubgraphvisited, path, 1);
        }
    }
}
void DFSPreContigs (PreSubGraph &G, int v, bool presubgraphvisited[], int path[], int depth) {
    for (ArcNode *arc=G.vexs[v].firstarc; arc!=NULL; arc=arc->nextarc) {
        if(G.vexs[arc->adjvex].outdegree==0){
            path[depth]=arc->adjvex;
            PrintPreContigs (G, path, depth+1);
        }
        if (!presubgraphvisited[arc->adjvex]) {
            presubgraphvisited[arc->adjvex]=true;
            path[depth]=arc->adjvex;
            DFSPreContigs(G, arc->adjvex, presubgraphvisited, path, depth+1);
        }
    }
}
void PrintPreContigs (PreSubGraph &G, int path[], int length) {
    vector<int> path_temp;
    for(int i=length-1; i>=0; i--) {
        path_temp.push_back(path[i]);
        if(i!=length-1 && G.vexs[path[i]].outdegree==0)
            break;
    }
    reverse(path_temp.begin(), path_temp.end());
    PreFragement_paths.push_back(path_temp);
}

#endif
