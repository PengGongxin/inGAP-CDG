//
//  preassembly.cpp
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#include "PreAssembly.h"
vector<bool> previsited;
map <int, set<int> > Pregraph_vertics;

preassembly::preassembly() {
    
}
preassembly::~preassembly() {
    
}
void preassembly::DFSPreGraph (Graph &G, int i, int pregraph_index) {
    previsited[i] = true;
    Pregraph_vertics[pregraph_index].insert(i);
    ArcNode *p;
    for (p=G.vexs[i].firstarc; p!=NULL; p=p->nextarc) {
        if (previsited[p->adjvex] == false ) {
            DFSPreGraph(G, p->adjvex, pregraph_index);
        }
    }
}
void preassembly::DFSPreGraphTraverse(Graph &G) {
    previsited.clear();
    for (int i=0; i < G.vexnum; i++)
        previsited.push_back(false);
    int pregraph_index =0;
    for (int i=0; i < G.vexnum; i++) {
        if (previsited[i] == false ) {
            DFSPreGraph(G, i, pregraph_index);
            pregraph_index++;
        }
    }
}
void preassembly::PreGraphNodeArc(int kmer, char *outdir) {
    fstream fin;
        //if (graph_type == "codon")
        fin.open((string(outdir).append("/SixFrameTranslation/graph.train.nuc").c_str()));
        //else if (graph_type == "peptide")
        //   fin.open((string(outdir).append("/SixFrameTranslation/graph.train.pep").c_str()));
    ofstream fout_kmer_info(string(outdir).append("/PreAssembly/node.info").c_str());
    ofstream fout_arc(string(outdir).append("/PreAssembly/arc").c_str());
    string buff;
    string s;
    map<string, int> kmer_cov;
    multimap<string, int> node_index1, node_index2;
        //if (graph_type == "codon") {
        while (getline(fin, buff, '\n')) {
            getline(fin, buff, '\n');
            for (int i=0; i < buff.length()-kmer+1; i+=3) {
                s = buff.substr(i, kmer);
                kmer_cov[s]++;
            }
        }
        int j = 0;
        for (map<string, int>::iterator kmer_cov_iter = kmer_cov.begin(); kmer_cov_iter != kmer_cov.end(); ++kmer_cov_iter) {
           // if (kmer_cov_iter->second >= 2) {
                node_index1.insert(make_pair(kmer_cov_iter->first.substr(3, kmer), j));
                node_index2.insert(make_pair(kmer_cov_iter->first.substr(0, kmer-3), j));
                fout_kmer_info << j << " " << kmer_cov_iter->first << " " << kmer_cov_iter->second <<endl;
                 ++j;
            //}
        }
        //}
    /*else if (graph_type == "peptide") {
        while (getline(fin, buff, '\n')) {
            getline(fin, buff, '\n');
            for (int i=0; i < buff.length()-kmer+1; i++) {
                s = buff.substr(i, kmer);
                kmer_cov[s]++;
            }
        }
        int j = 0;
        for (map<string, int>::iterator kmer_cov_iter = kmer_cov.begin(); kmer_cov_iter != kmer_cov.end(); ++kmer_cov_iter) {
            //if (kmer_cov_iter->second >= 2) {
                node_index1.insert(make_pair(kmer_cov_iter->first.substr(1, kmer), j));
                node_index2.insert(make_pair(kmer_cov_iter->first.substr(0, kmer-1), j));
                fout_kmer_info << j << " " << kmer_cov_iter->first << " " << kmer_cov_iter->second <<endl;
                ++j;
            //}
        }
    }*/
    map<string, int>().swap(kmer_cov);
    for (multimap<string, int>::iterator node_index1_iter = node_index1.begin() ; node_index1_iter != node_index1.end(); ) {
        multimap<string, int>::iterator node_index2_iter = node_index2.find(node_index1_iter->first);
        if (node_index2_iter != node_index2.end()) {
            unsigned long num = node_index2.count(node_index1_iter->first);
            for (int m=0; m < num; m++) {
                if (node_index1_iter->second != node_index2_iter->second)
                    fout_arc << node_index1_iter->second << " " << node_index2_iter->second << endl;
                ++node_index2_iter;
            }
        }
        ++node_index1_iter;
    }
    multimap<string, int>().swap(node_index1);
    multimap<string, int>().swap(node_index2);
    fout_kmer_info.close();
    fout_arc.close();
}
void preassembly::PreAssemblyTrain(int kmer, char *outdir) {
    Graph Undirected_Pregraph, Directed_Pregraph, Reverse_Pregraph;
    CreateDirectedGraph_file(Directed_Pregraph, string(outdir).append("/PreAssembly"));
        //cout << Directed_Pregraph.vexnum << " " << Directed_Pregraph.arcnum <<endl;
    Reverse_Pregraph.vexnum = Directed_Pregraph.vexnum;
    Undirected_Pregraph.vexnum = Directed_Pregraph.vexnum;
    CreateReverseDirectedGraph_file(Reverse_Pregraph, string(outdir).append("/PreAssembly"));
    CreateUndirectedGraph_file(Undirected_Pregraph, string(outdir).append("/PreAssembly"));
    for (int i=0; i < Directed_Pregraph.vexnum; i++) {
        Directed_Pregraph.vexs[i].indegree = GetOutdegree(Reverse_Pregraph, i);
        Directed_Pregraph.vexs[i].outdegree = GetOutdegree(Directed_Pregraph, i);
    }
    ClearGraph(Reverse_Pregraph);
    DFSPreGraphTraverse(Undirected_Pregraph);
    cout << Pregraph_vertics.size() << endl;
    ofstream fout;
        //if(graph_type == "codon")
        fout.open(string(outdir).append("/PreAssembly/precontigs.nuc.fas").c_str());
        //else if(graph_type == "peptide")
        //  fout.open(string(outdir).append("/PreAssembly/precontigs.pep.fas").c_str());
    for (int i = 0; i < Pregraph_vertics.size(); i++) {
        if (Pregraph_vertics[i].size() >= 450 && Pregraph_vertics[i].size() <= 50000) {
                //cout << Pregraph_vertics[i].size() << endl;
            pregraph_nodes_map_presubgraph.clear();
            presubgraph_nodes_map_pregraph.clear();
            int node_index = 0;
            for (set<int>::iterator iter = Pregraph_vertics[i].begin(); iter != Pregraph_vertics[i].end(); iter++) {
                pregraph_nodes_map_presubgraph[*iter] = node_index;
                presubgraph_nodes_map_pregraph[node_index] = *iter;
                node_index++;
            }
            PreSubGraph Pre_subgraph;
            Pre_subgraph.vexnum = node_index;
            Origin_presubgraph_vertics_number = node_index;
            for (int j = 0; j < Pre_subgraph.vexnum; j++)
                Pre_subgraph.vexs[j].firstarc = NULL;
            Pre_subgraph.arcnum = 0;
            for (map<int,int>::iterator iter=pregraph_nodes_map_presubgraph.begin(); iter!=pregraph_nodes_map_presubgraph.end(); ++iter) {
                Pre_subgraph.vexs[iter->second].indegree = Directed_Pregraph.vexs[iter->first].indegree;
                Pre_subgraph.vexs[iter->second].outdegree = Directed_Pregraph.vexs[iter->first].outdegree;
                Pre_subgraph.vexs[iter->second].kmer = Directed_Pregraph.vexs[iter->first].kmer;
                ArcNode *p;
                p = Directed_Pregraph.vexs[iter->first].firstarc;
                while (p!=NULL) {
                    InsertPreArc(Pre_subgraph, iter->second, pregraph_nodes_map_presubgraph[p->adjvex]);
                    p=p->nextarc;
                }
            }
            PreFragement_paths.clear();
            FindPreContigs(Pre_subgraph);
            vector<string> Precontigs;
            string contigs_id = ">contigs" + int2string(i+1) ;
            for (int m=0; m< PreFragement_paths.size(); m++) {
                string contigs_seq;
                for (int j=0; j< PreFragement_paths[m].size(); j++) {
                    if(j==0)
                        contigs_seq = Pre_subgraph.vexs[PreFragement_paths[m][j]].kmer;
                    if(j>0) {
                            //if (graph_type == "codon")
                            contigs_seq.append(Pre_subgraph.vexs[PreFragement_paths[m][j]].kmer.substr(kmer-3));
                            //else if (graph_type == "peptide")
                            //contigs_seq.append(Pre_subgraph.vexs[PreFragement_paths[m][j]].kmer.substr(kmer-1));
                    }
                }
                Precontigs.push_back(contigs_seq);
            }
            if (Precontigs.size() > 1)
                sort(Precontigs.begin(), Precontigs.end(), CMP_String_Length);
            if (Precontigs.size() >0 && Precontigs[0].length() >= 500)
                fout << contigs_id << "\n" << Precontigs[0] << endl;
        }
    }
    map<int, set<int> >().swap(Pregraph_vertics);
    ClearGraph(Directed_Pregraph);
    fout.close();
}
void preassembly::PreAssemblyStage(int kmer, char *outdir) {
    string PreAssemblyDir = string(outdir).append("/PreAssembly");
    mkdir(PreAssemblyDir.c_str(), 0755);
    PreGraphNodeArc(kmer, outdir);
    PreAssemblyTrain(kmer, outdir);
    
}


