//
//  SixFrameTranslation.h
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_transcriptToCDS_SixFrameTranslation_h
#define openMP_libsvm_inGAP_CDG_transcriptToCDS_SixFrameTranslation_h

#include "common.h"

class SixFrameTranslation {
public:
    SixFrameTranslation();
    virtual ~SixFrameTranslation();
    void Format_Infile(char *, char *);
    string Reverse_complement(string);
    void Find_NucSeq(string);
    void Find_NucSeq_long_reads(string);
    void Find_Orf_length(string);
    string Find_NucSeq_StopCodonsNum(string, int);
    string Find_NucSeq_StopCodonsNum_long_reads(string, int);
    void SixFrameTranslationStage(char *, char *, int);
        //void SixFrameTranslationStageAssemblyStrategy(char *,char *, char*, int);
   
};


#endif
