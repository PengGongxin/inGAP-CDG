//
//  commom.h
//  openMP_SVM_inGAP-CDG_transcriptToCDS
//
//  Created by Peng Gongxin on 1/28/15.
//  Copyright (c) 2014 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_transcriptToCDS_commom_h
#define openMP_libsvm_inGAP_CDG_transcriptToCDS_commom_h

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <algorithm>
#include <iterator>
#include <map>
#include <set>
#include <cstdio>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <limits.h>
#include <unistd.h>
#include <mach-o/dyld.h>
using namespace std;
const string Codons[64] = { "AAA","AAC","AAG","AAT","ACA","ACC","ACG","ACT","AGA","AGC","AGT","AGG","ATA","ATC","ATG","ATT","CAA","CAC","CAG","CAT","CCA","CCC","CCG","CCT","CGA","CGC","CGT","CGG","CTA","CTC","CTG","CTT","GAA","GAC","GAG","GAT","GCA","GCC","GCG","GCT","GGA","GGC","GGT","GGG","GTA","GTC","GTG","GTT","TAA","TAC","TAG","TAT","TCA","TCC","TCG","TCT","TGA","TGC","TGT","TGG","TTA","TTC","TTG","TTT" };
const string Peptides[20] = {"A", "C", "D", "E", "F", "G", "H", "I", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "Z"};
struct ArcNode {
    int adjvex;
    ArcNode *nextarc;
};
struct VexNode{
    int index;
    string kmer;
    int coverage;
    int indegree;
    int outdegree;
    ArcNode *firstarc;
};
map<string, string> GeneticCodeTable;
void GeneticCode() {
    /*the general codons code table*/
    GeneticCodeTable.insert(make_pair("TAA", "*"));
    GeneticCodeTable.insert(make_pair("TAG", "*"));
    GeneticCodeTable.insert(make_pair("TGA", "*"));
    
    GeneticCodeTable.insert(make_pair("GCA", "A"));
    GeneticCodeTable.insert(make_pair("GCC", "A"));
    GeneticCodeTable.insert(make_pair("GCG", "A"));
    GeneticCodeTable.insert(make_pair("GCT", "A"));
    
    GeneticCodeTable.insert(make_pair("TGC", "C"));
    GeneticCodeTable.insert(make_pair("TGT", "C"));
    
    GeneticCodeTable.insert(make_pair("GAC", "D"));
    GeneticCodeTable.insert(make_pair("GAT", "D"));

    GeneticCodeTable.insert(make_pair("GAA", "E"));
    GeneticCodeTable.insert(make_pair("GAG", "E"));
    
    GeneticCodeTable.insert(make_pair("TTC", "F"));
    GeneticCodeTable.insert(make_pair("TTT", "F"));
    
    GeneticCodeTable.insert(make_pair("GGA", "G"));
    GeneticCodeTable.insert(make_pair("GGC", "G"));
    GeneticCodeTable.insert(make_pair("GGG", "G"));
    GeneticCodeTable.insert(make_pair("GGT", "G"));
    
    GeneticCodeTable.insert(make_pair("CAC", "H"));
    GeneticCodeTable.insert(make_pair("CAT", "H"));
    
    GeneticCodeTable.insert(make_pair("ATA", "I"));
    GeneticCodeTable.insert(make_pair("ATC", "I"));
    GeneticCodeTable.insert(make_pair("ATT", "I"));

    GeneticCodeTable.insert(make_pair("AAA", "K"));
    GeneticCodeTable.insert(make_pair("AAG", "K"));

    GeneticCodeTable.insert(make_pair("TTA", "L"));
    GeneticCodeTable.insert(make_pair("TTG", "L"));
    GeneticCodeTable.insert(make_pair("CTA", "L"));
    GeneticCodeTable.insert(make_pair("CTC", "L"));
    GeneticCodeTable.insert(make_pair("CTG", "L"));
    GeneticCodeTable.insert(make_pair("CTT", "L"));
    
    GeneticCodeTable.insert(make_pair("ATG", "M"));
    
    GeneticCodeTable.insert(make_pair("AAT", "N"));
    GeneticCodeTable.insert(make_pair("AAC", "N"));
    
    GeneticCodeTable.insert(make_pair("CCA", "P"));
    GeneticCodeTable.insert(make_pair("CCC", "P"));
    GeneticCodeTable.insert(make_pair("CCG", "P"));
    GeneticCodeTable.insert(make_pair("CCT", "P"));
    
    GeneticCodeTable.insert(make_pair("CAA", "Q"));
    GeneticCodeTable.insert(make_pair("CAG", "Q"));
    
    GeneticCodeTable.insert(make_pair("CGA", "R"));
    GeneticCodeTable.insert(make_pair("CGC", "R"));
    GeneticCodeTable.insert(make_pair("CGG", "R"));
    GeneticCodeTable.insert(make_pair("CGT", "R"));
    GeneticCodeTable.insert(make_pair("AGA", "R"));
    GeneticCodeTable.insert(make_pair("AGG", "R"));

    GeneticCodeTable.insert(make_pair("TCA", "S"));
    GeneticCodeTable.insert(make_pair("TCC", "S"));
    GeneticCodeTable.insert(make_pair("TCG", "S"));
    GeneticCodeTable.insert(make_pair("TCT", "S"));
    GeneticCodeTable.insert(make_pair("AGC", "S"));
    GeneticCodeTable.insert(make_pair("AGT", "S"));

    GeneticCodeTable.insert(make_pair("ACA", "T"));
    GeneticCodeTable.insert(make_pair("ACC", "T"));
    GeneticCodeTable.insert(make_pair("ACG", "T"));
    GeneticCodeTable.insert(make_pair("ACT", "T"));
    
    GeneticCodeTable.insert(make_pair("GTA", "V"));
    GeneticCodeTable.insert(make_pair("GTC", "V"));
    GeneticCodeTable.insert(make_pair("GTG", "V"));
    GeneticCodeTable.insert(make_pair("GTT", "V"));
    
    GeneticCodeTable.insert(make_pair("TGG", "W"));
   
    GeneticCodeTable.insert(make_pair("TAC", "Y"));
    GeneticCodeTable.insert(make_pair("TAT", "Y"));
}
bool CMP_String_Length(const string left, const string right) {
    return left.length() > right.length(); /* sort by the rule : the size of string length*/
}
bool CMP_Vector_Length(const vector<int> left, const vector<int> right) {
    return left.size() > right.size(); /*sort the element of vector by rule: the size of element*/
}
string int2string(const int n) {
    /*the types of data change  int ->  string*/
    stringstream newstr;
    newstr << n;
    return newstr.str();
}
string float2string(const float n) {
    /*the types of data change  float ->  string*/
    stringstream newstr;
    newstr << n;
    return newstr.str();
}
string NucTransPep(string s) {
    string peptide;
    for (int i=0; i < s.length()-2; i += 3)
        peptide.append(GeneticCodeTable[s.substr(i,3)]);
    return peptide;
}


string get_program_dir() {
    char path[512];
    unsigned size= 512;
    _NSGetExecutablePath(path, &size);
        //struct utsname u;
        //string sys_name=string(u.sysname);
    string s=string(path);
    unsigned long int position=s.find_last_of('/');
    string path_program=s.substr(0,position);
    return path_program;
}

void KmerInfo(int kmer) {
    if (kmer <15) {
        cout << "Warning: the kmer length is smaller, please check '-k' option." << endl;
    }
    else if (kmer >48) {
        cout << "Warning: the kmer length is longer, please check '-k' option." << endl;
    }
    
}

#endif
