//
//  assembly.h
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_CDG_readToCDS_assembly_h
#define openMP_libsvm_inGAP_CDG_readToCDS_assembly_h

#include "graph.h"
#include "AssemblySubgraph.h"

class assembly {
public:
    assembly();
    virtual ~assembly();
    void DFSSubgraph (Graph &, int, int);
    void DFSSubgraphTraverse (Graph &);
    void GraphNodeArc (int,  char *);
    void ContigsAssembly (int, int, char *);
    void ContigsAssemblyStage(int, int,  char *);
};
#endif
