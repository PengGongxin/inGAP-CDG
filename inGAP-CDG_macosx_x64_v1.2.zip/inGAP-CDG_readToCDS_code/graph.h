//
//  graph.h
//
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 6/25/16.
//  Copyright (c) 2016 Peng Gongxin. All rights reserved.
//

#ifndef openMP_libsvm_inGAP_DB_graph_h
#define openMP_libsvm_inGAP_DB_graph_h

#include "common.h"

struct Graph {
    vector<VexNode> vexs;
    int vexnum;
    int arcnum;
};

void CreateDirectedGraph_file(Graph &G, string outdir) {
    int node_index, node_coverage;
    string node_kmer;
    string outfile=outdir;
    ifstream fin_node;
    fin_node.open(outdir.append("/node.info").c_str());
    int node_id =0 ;
    while (fin_node >> node_index >> node_kmer >> node_coverage) {
            //VexNode *p; p = new VexNode; p->index = node_index; ...
        VexNode p;
        p.index = node_index;
        p.kmer = node_kmer;
        p.coverage = node_coverage;
        p.firstarc = NULL;       // graph arcs initialization! important.
        G.vexs.push_back(p);
        node_id++;
    }
    G.vexnum = node_id;
    ifstream fin_edge;
    fin_edge.open(outfile.append("/arc").c_str());
    int arc_front, arc_rear, arc_id = 0;
    while (fin_edge >> arc_front >> arc_rear) {
        ArcNode *p;
        p = new ArcNode;
        p->adjvex = arc_rear;
        p->nextarc = G.vexs[arc_front].firstarc;
        G.vexs[arc_front].firstarc = p;
        arc_id ++;
    }
    G.arcnum = arc_id;
        //cout << "directed graph finished "  <<  G.vexnum << " " << G.arcnum  <<   endl;
    fin_node.close();
    fin_edge.close();
}
void CreateUndirectedGraph_file(Graph &G, string outdir) {
    for (int i=0; i < G.vexnum; i++) {
        VexNode p;
        p.firstarc = NULL;
        G.vexs.push_back(p);
    }
    ifstream fin_edge;
    fin_edge.open(outdir.append("/arc").c_str());
    int arc_front, arc_rear;
    while (fin_edge >> arc_front >> arc_rear) {
        ArcNode *p, *q;
        p = new ArcNode;
        q = new ArcNode;
        p->adjvex = arc_rear;
        p->nextarc = G.vexs[arc_front].firstarc;
        G.vexs[arc_front].firstarc = p;
        q->adjvex = arc_front;
        q->nextarc =G.vexs[arc_rear].firstarc;
        G.vexs[arc_rear].firstarc =q;
    }
        //cout << "undirected graph finished "  <<  G.vexnum << " " << G.arcnum  <<   endl;
    fin_edge.close();
}
void CreateReverseDirectedGraph_file(Graph &G, string outdir) {
    for (int i=0; i < G.vexnum; i++) {
        VexNode p;
        p.firstarc = NULL;
        G.vexs.push_back(p);
    }
    ifstream fin_edge;
    fin_edge.open(outdir.append("/arc").c_str());
    int arc_front, arc_rear;
    while (fin_edge >> arc_rear >> arc_front) {
        ArcNode *p;
        p = new ArcNode;
        p->adjvex = arc_rear;
        p->nextarc = G.vexs[arc_front].firstarc;
        G.vexs[arc_front].firstarc = p;
    }
        //cout << "reverse directed graph finished "  <<  G.vexnum << " " << G.arcnum  <<   endl;
    fin_edge.close();
}
int GetIndegree(Graph &G, int i) {
    int count = 0;
    for(int j = 0; j < G.vexnum; j++) {
        ArcNode *p;
        p = G.vexs[j].firstarc;
        if (p == NULL)
            continue;
        while (p) {
            if (p->adjvex == i) {
                count++;
                p = p->nextarc;
            }
            else
                p = p->nextarc;
        }
    }
    if(count != 0)
        return count;
    else
        return 0;
}
int GetOutdegree(Graph &G, int i) {
    int count = 0;
    ArcNode *p;
    p = G.vexs[i].firstarc;
    if(p == NULL)
        return 0;
    while (p) {
        count++;
        p = p->nextarc;
    }
    return count;
}
void ClearGraph (Graph &G) {
    for (int i=0; i<G.vexnum; i++) {
        while (G.vexs[i].firstarc!=NULL) {
            ArcNode *p=G.vexs[i].firstarc;
            G.vexs[i].firstarc=p->nextarc;
            delete []p;
        }
    }
    G.vexnum=0;
    G.arcnum=0;
}


#endif
