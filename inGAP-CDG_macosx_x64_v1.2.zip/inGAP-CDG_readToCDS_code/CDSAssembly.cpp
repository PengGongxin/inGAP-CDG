//
//  CDSAssembly.cpp
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 7/26/16.
//  Copyright © 2016 Peng Gongxin. All rights reserved.
//

#include "CDSAssembly.h"
vector<bool> cdsvisited;
map <int, set<int> > cdsgraph_vertics;

cdsassembly::cdsassembly() {
    
}
cdsassembly::~cdsassembly() {
    
}
void cdsassembly::DFScdsGraph (Graph &G, int i, int cdsgraph_index) {
    cdsvisited[i] = true;
    cdsgraph_vertics[cdsgraph_index].insert(i);
    ArcNode *p;
    for (p=G.vexs[i].firstarc; p!=NULL; p=p->nextarc) {
        if (cdsvisited[p->adjvex] == false ) {
            DFScdsGraph(G, p->adjvex, cdsgraph_index);
        }
    }
}
void cdsassembly::DFScdsGraphTraverse(Graph &G) {
    cdsvisited.clear();
    for (int i=0; i < G.vexnum; i++)
        cdsvisited.push_back(false);
    int cdsgraph_index =0;
    for (int i=0; i < G.vexnum; i++) {
        if (cdsvisited[i] == false ) {
            DFScdsGraph(G, i, cdsgraph_index);
            cdsgraph_index++;
        }
    }
}
void cdsassembly::cdsAssemblyBlat(char *outdir, string program_dir) {
    string blat_command = program_dir;
    string out_dir = string(outdir);
    string run_blat_command = blat_command + "/blat " + out_dir + "/ScaffoldsAssembly/scaffolds.nuc.fas " +out_dir + "/ScaffoldsAssembly/scaffolds.nuc.fas "+out_dir+"/cdsAssembly/scaffolds.psl";
    const char *RUN_BLAT_COMMAND= run_blat_command.c_str();
    system(RUN_BLAT_COMMAND);
        //string get_unoverlap_command = "cat " + out_dir +"/cdsAssembly/scaffolds.psl | sed '1,5d'  | awk '{if($1>=100)print $10}' | sort |uniq -c|awk '{print $1,$2}'|awk '{if($1==1)print $2}' >"+ out_dir + "/cdsAssembly/scaffolds.psl.filter.unoverlap.id.one";
        //const char *GET_UNOVERLAP_COMMAND = get_unoverlap_command.c_str();
        //system(GET_UNOVERLAP_COMMAND);
    
    
    string get_unoverlap_blat_command = "cat " + out_dir +"/cdsAssembly/scaffolds.psl | sed '1,5d' | awk '{if($10!=$14)print}' |awk '{if( ($11>=$15 && $1/$15>=0.8) || ($11<$15 && $1/$11>=0.8) ){if($11>=$15){print $10, $14}else{print $14,$10}}}' | sort -u >"+ out_dir + "/cdsAssembly/scaffolds.psl.filter.unoverlap.id";
    const char *GET_UNOVERLAP_BLAT_COMMAND = get_unoverlap_blat_command.c_str();
    system(GET_UNOVERLAP_BLAT_COMMAND);

    string filter_blat_command = "cat " + out_dir +"/cdsAssembly/scaffolds.psl | sed '1,5d' | awk '{if($1>=30 && $10!=$14)  {if ($1/$11<0.8 || $1/$15<0.8)print $10,$11,$12,$13,$14,$15,$16,$17}}' | awk '{if($2-$4<=100 && $7<=100)print}' >"+ out_dir + "/cdsAssembly/scaffolds.psl.filter";
    const char *FILTER_BLAT_COMMAND = filter_blat_command.c_str();
    system(FILTER_BLAT_COMMAND);
    
}
void cdsassembly::cdsGraphNodeArc(int kmer, char *outdir) {
    ifstream fin(string(outdir).append("/cdsAssembly/scaffolds.psl.filter").c_str());
        //ifstream fin_unoverlap_filter(string(outdir).append("/cdsAssembly/scaffolds.psl.filter.unoverlap.id.one").c_str());
    ifstream fin_unoverlap_filter_redun(string(outdir).append("/cdsAssembly/scaffolds.psl.filter.unoverlap.id").c_str());
    ifstream fin_scaffold(string(outdir).append("/ScaffoldsAssembly/scaffolds.nuc.fas").c_str());
    ofstream fout_kmer_info(string(outdir).append("/cdsAssembly/node.info").c_str());
    ofstream fout_arc(string(outdir).append("/cdsAssembly/arc").c_str());
    ofstream fout_unoverlap(string(outdir).append("/cdsAssembly/cds.unoverlap.nuc.fas").c_str());
    ofstream fout_unoverlap_redun(string(outdir).append("/cdsAssembly/cds.unoverlap.redun.nuc.fas").c_str());
    string qid, tid;
    int qsize, qstart, qend, tsize, tstart, tend;
    set <string> overlap_id, unoverlap_filter_id;
    map <int, string> overlap_num_id;
    map <string,int> overlap_id_num;
    map <string, string> scaffold_id_seq, scaffold_overlap_id_seq;
    string s;
    while (getline(fin_scaffold, s, '\n')) {
        if(s=="")
            continue;
        string id = s.substr(1);
        getline(fin_scaffold, s, '\n');
        scaffold_id_seq[id]=s;
    }
        //cout << "scaffold_id_seq" << scaffold_id_seq.size() << endl;
    string temp1, temp2;
   set<string> long_id, short_id;
   while (fin_unoverlap_filter_redun >> temp1 >> temp2) {
       long_id.insert(temp1);
       short_id.insert(temp2);
       unoverlap_filter_id.insert(temp1);
       unoverlap_filter_id.insert(temp2);
    }
    set<string> scaffold_redun_cluster_id;
    for (set<string>::iterator iter= long_id.begin(); iter!=long_id.end(); iter++) {
        set<string>::iterator iter1=short_id.find(*iter);
        if(iter1 == short_id.end())
         scaffold_redun_cluster_id.insert(*iter);
    }
    while (fin >> qid >>qsize >> qstart >> qend >> tid >>tsize >> tstart >> tend) {
        overlap_id.insert(qid);
        overlap_id.insert(tid);
    }
        //cout << "overlap_id size:" << overlap_id.size() <<endl;
    set<string>:: iterator iter, iter1;
    for (map<string, string>::iterator iter_all= scaffold_id_seq.begin(); iter_all != scaffold_id_seq.end(); iter_all++) {
        iter= overlap_id.find(iter_all->first);
        iter1= unoverlap_filter_id.find(iter_all->first);
        if (iter != overlap_id.end())
            scaffold_overlap_id_seq[iter_all->first] = iter_all->second;
        else if (iter1 == unoverlap_filter_id.end()) {
            if (iter_all->second.length() >=400)
                fout_unoverlap << ">" << iter_all->first << "\n" << iter_all->second << endl;
        }
    }
    for(set<string>::iterator iter=scaffold_redun_cluster_id.begin(); iter!=scaffold_redun_cluster_id.end(); iter++) {
        fout_unoverlap_redun << ">"<<  *iter << "\n" << scaffold_id_seq[*iter] << endl;
    }
    int i=0;
    for (set<string>::iterator it = overlap_id.begin(); it != overlap_id.end(); it++) {
        
        string temp = *it;
        overlap_num_id[i]= temp;
        overlap_id_num[temp] = i;
        fout_kmer_info << i << " " << scaffold_overlap_id_seq[temp] << " 1" << endl;
        i++;
    }
        //vector<int> classfiy_id;
        // classfiy_id.push_back(-1);
    ifstream fin1(string(outdir).append("/cdsAssembly/scaffolds.psl.filter").c_str());

    while (fin1 >> qid >>qsize >> qstart >> qend >> tid >>tsize >> tstart >> tend) {
        fout_arc<< overlap_id_num[qid] << " " << overlap_id_num[tid] << endl;
        vector <int> temp, temp1;
        temp.push_back(overlap_id_num[qid]);
            //vector<int>::iterator iter=find(classfiy_id.begin(), classfiy_id.end(), overlap_id_num[qid]);
            //if (iter == classfiy_id.end())
        temp.push_back(0);
        scaffolf_kmer_info[temp] = scaffold_overlap_id_seq[qid].substr(0, qstart/3*3+3);
        temp1.push_back(overlap_id_num[tid]);
        temp1.push_back(1);
        scaffolf_kmer_info[temp1] = scaffold_overlap_id_seq[tid];
    }
    fin.close();
    fin_scaffold.close();
    fout_unoverlap.close();
    fout_kmer_info.close();
    fout_arc.close();
    
}
void cdsassembly::cdsAssemblyTrain(int kmer, char *outdir) {
    Graph Undirected_cdsgraph, Directed_cdsgraph, Reverse_cdsgraph;
    CreateDirectedGraph_file(Directed_cdsgraph, string(outdir).append("/cdsAssembly"));
        //cout << Directed_cdsgraph.vexnum << " " << Directed_cdsgraph.arcnum <<endl;
    Reverse_cdsgraph.vexnum = Directed_cdsgraph.vexnum;
    Undirected_cdsgraph.vexnum = Directed_cdsgraph.vexnum;
    CreateReverseDirectedGraph_file(Reverse_cdsgraph, string(outdir).append("/cdsAssembly"));
    CreateUndirectedGraph_file(Undirected_cdsgraph, string(outdir).append("/cdsAssembly"));
    for (int i=0; i < Directed_cdsgraph.vexnum; i++) {
        Directed_cdsgraph.vexs[i].indegree = GetOutdegree(Reverse_cdsgraph, i);
        Directed_cdsgraph.vexs[i].outdegree = GetOutdegree(Directed_cdsgraph, i);
    }
    ClearGraph(Reverse_cdsgraph);
    DFScdsGraphTraverse(Undirected_cdsgraph);
        //cout << cdsgraph_vertics.size() << endl;
    ofstream fout;
    fout.open(string(outdir).append("/cdsAssembly/cds.overlap.nuc.fas").c_str());
    for (int i = 0; i < cdsgraph_vertics.size(); i++) {
        if (cdsgraph_vertics[i].size() > 0 && cdsgraph_vertics[i].size() <= 50) {
            cdsgraph_nodes_map_cdssubgraph.clear();
            cdssubgraph_nodes_map_cdsgraph.clear();
            int node_index = 0;
            for (set<int>::iterator iter = cdsgraph_vertics[i].begin(); iter != cdsgraph_vertics[i].end(); iter++) {
                cdsgraph_nodes_map_cdssubgraph[*iter] = node_index;
                cdssubgraph_nodes_map_cdsgraph[node_index] = *iter;
                node_index++;
            }
            cdsSubGraph cds_subgraph;
            cds_subgraph.vexnum = node_index;
            Origin_cdssubgraph_vertics_number = node_index;
            for (int j = 0; j < cds_subgraph.vexnum; j++)
                cds_subgraph.vexs[j].firstarc = NULL;
            cds_subgraph.arcnum = 0;
            for (map<int,int>::iterator iter=cdsgraph_nodes_map_cdssubgraph.begin(); iter!=cdsgraph_nodes_map_cdssubgraph.end(); ++iter) {
                cds_subgraph.vexs[iter->second].indegree = Directed_cdsgraph.vexs[iter->first].indegree;
                cds_subgraph.vexs[iter->second].outdegree = Directed_cdsgraph.vexs[iter->first].outdegree;
                cds_subgraph.vexs[iter->second].kmer = Directed_cdsgraph.vexs[iter->first].kmer;
                ArcNode *p;
                p = Directed_cdsgraph.vexs[iter->first].firstarc;
                while (p!=NULL) {
                    InsertcdsArc(cds_subgraph, iter->second, cdsgraph_nodes_map_cdssubgraph[p->adjvex]);
                    p=p->nextarc;
                }
            }
            cdsFragement_paths.clear();
            FindcdsContigs(cds_subgraph);
            if ( cdsFragement_paths[1].size() <=10 )  {
            vector<string> cdscontigs;
            string contigs_id = ">contigs" + int2string(i+1) ;
            for (int m=0; m< cdsFragement_paths.size(); m++) {
                string contigs_seq;
                for (int j=0; j< cdsFragement_paths[m].size(); j++) {
                    if(j==0) {
                        vector<int> node_info;
                        node_info.push_back(cdssubgraph_nodes_map_cdsgraph[cdsFragement_paths[m][j]]);
                        if (cds_subgraph.vexs[cdsFragement_paths[m][j]].indegree==0)
                            node_info.push_back(0);
                        else
                            node_info.push_back(1);
                        contigs_seq = scaffolf_kmer_info[node_info];
                            //contigs_seq = cds_subgraph.vexs[cdsFragement_paths[m][j]].kmer;
                    }
                    if(j>0) {
                        vector<int> node_info;
                        node_info.push_back(cdssubgraph_nodes_map_cdsgraph[cdsFragement_paths[m][j]]);
                        if (cds_subgraph.vexs[cdsFragement_paths[m][j]].indegree==0)
                            node_info.push_back(0);
                        else
                            node_info.push_back(1);
                        contigs_seq.append(scaffolf_kmer_info[node_info]);
                    }
                }
                cdscontigs.push_back(contigs_seq);
            }
            if (cdscontigs.size() > 1)
                sort(cdscontigs.begin(), cdscontigs.end(), CMP_String_Length);
            if (cdscontigs.size() >0 && cdscontigs[0].length() >= 150)
                fout << contigs_id << "\n" << cdscontigs[0] << endl;
        }
        }
    }
    map<int, set<int> >().swap(cdsgraph_vertics);
    ClearGraph(Directed_cdsgraph);
    fout.close();
        //cout << "finished cdsAssembly" <<endl;
    }
void cdsassembly::cdsAssemblyFinal(char *outdir, string program_dir) {
    ofstream fout_nuc_300(string(outdir).append("/OutputCDSs/cds.nuc.fas").c_str());
    ofstream fout_pep_100(string(outdir).append("/OutputCDSs/cds.pep.fas").c_str());
    string out_dir = string(outdir);
    string cat_temp_command =  "cat " + out_dir + "/cdsAssembly/cds.overlap.nuc.fas "+out_dir + "/cdsAssembly/cds.unoverlap.redun.nuc.fas "+out_dir + "/cdsAssembly/cds.unoverlap.nuc.fas > "+out_dir + "/cdsAssembly/temp.fas ";
    const char *CAT_TEMP_COMMAND= cat_temp_command.c_str();
    system(CAT_TEMP_COMMAND);
    
    string blat_command = program_dir;
    string run_blat_command = blat_command + "/blat " + out_dir + "/cdsAssembly/temp.fas " +out_dir + "/cdsAssembly/temp.fas "+out_dir+"/cdsAssembly/temp.psl";
    const char *RUN_BLAT_COMMAND= run_blat_command.c_str();
    system(RUN_BLAT_COMMAND);
    string get_unoverlap_blat_command = "cat " + out_dir +"/cdsAssembly/temp.psl | sed '1,5d' | awk '{if($10!=$14)print}' |awk '{if( ($11>=$15 && $1/$15>=0.95) || ($11<$15 && $1/$11>=0.95) ){if($11>=$15){print $10, $14}else{print $14,$10}}}' | sort -u >"+ out_dir + "/cdsAssembly/temp.psl.filter.unoverlap.id";
    const char *GET_UNOVERLAP_BLAT_COMMAND = get_unoverlap_blat_command.c_str();
    system(GET_UNOVERLAP_BLAT_COMMAND);
    
    ifstream fin(string(outdir).append("/cdsAssembly/temp.fas").c_str());
    ifstream fin_unoverlap_filter_redun(string(outdir).append("/cdsAssembly/temp.psl.filter.unoverlap.id").c_str());
    ofstream fin_out(string(outdir).append("/cdsAssembly/temp_final.fas").c_str());
    string temp1, temp2;
    set<string> long_id, short_id;
    while (fin_unoverlap_filter_redun >> temp1 >> temp2) {
        long_id.insert(temp1);
        short_id.insert(temp2);
    }
    string temp_s;
    while(getline(fin,temp_s,'\n')) {
        string temp_s_id=temp_s.substr(1);
        getline(fin, temp_s,'\n');
        set<string>::iterator iter=short_id.find(temp_s_id);
        if (iter == short_id.end())
            fin_out << ">" << temp_s_id << "\n" <<temp_s << endl;
    }
    fin.close();
    fin_unoverlap_filter_redun.close();
    fin_out.close();
   
    
    ifstream fin_all(string(outdir).append("/cdsAssembly/temp_final.fas").c_str());
    string s;
    int id=1;
    while (getline(fin_all, s, '\n')) {
        string seq, pep;
        if(s=="")
            continue;
        getline(fin_all,s,'\n');
        if (s.length() >= 300) {
            fout_nuc_300 << ">cds" <<id << endl;
            fout_nuc_300 << s << endl;
            id++;
        }
    }
    ifstream fin_all_1(string(outdir).append("/OutputCDSs/cds.nuc.fas").c_str());
    while (getline(fin_all_1, s, '\n')) {
        string id=s;
        string pep;
        if(s=="")
            continue;
        getline(fin_all_1,s,'\n');
        for(int i=0; i<s.length()-2; i+=3)
            pep.append(GeneticCodeTable[s.substr(i, 3)]);
        fout_pep_100 << id << "\n" << pep <<endl;
    }
    string rm_temp_command = "rm "+out_dir+"/cdsAssembly/*";
    const char *RUN_TEMP_COMMAND= rm_temp_command.c_str();
    system(RUN_TEMP_COMMAND);
        //string rm_temp1_command = "rm -rf "+out_dir+"/cdsAssembly";
        //const char *RUN_TEMP1_COMMAND= rm_temp1_command.c_str();
        //system(RUN_TEMP1_COMMAND);
    string rm1_temp_command ="mv "+out_dir+"/cdsAssembly "+out_dir+"/ScaffoldsAssembly/temp";
    const char *RUN1_TEMP_COMMAND= rm1_temp_command.c_str();
    system(RUN1_TEMP_COMMAND);
    
    fin_all.close();
    fin_all_1.close();
    fout_nuc_300.close();
    fout_pep_100.close();
}
void cdsassembly::cdsAssemblyStage(int kmer, char *outdir) {
    string cdsAssemblyDir = string(outdir).append("/cdsAssembly");
    mkdir(cdsAssemblyDir.c_str(), 0755);
    string OutputCDSsDir = string(outdir).append("/OutputCDSs");
    mkdir(OutputCDSsDir.c_str(), 0755);
    string s=get_program_dir();
    string program_dir=s.append("/tools/");
    cdsAssemblyBlat(outdir, program_dir);
    cdsGraphNodeArc(kmer, outdir);
    cdsAssemblyTrain(kmer, outdir);
    cdsAssemblyFinal(outdir, program_dir);
    
}
