//
//  CDSAssemblySubgraph.h
//  inGAP-CDG_readToCDS
//
//  Created by Peng Gongxin on 7/26/16.
//  Copyright © 2016 Peng Gongxin. All rights reserved.
//

#ifndef CDSAssemblySubgraph_h
#define CDSAssemblySubgraph_h

const int Max_cdsSubgraph_VertexNum= 50000;
int Origin_cdssubgraph_vertics_number;
bool cdssubgraphvisited[Max_cdsSubgraph_VertexNum];
vector< vector<int> > cdsFragement_paths;
map <vector<int>, string> scaffolf_kmer_info;
map<int, int> cdsgraph_nodes_map_cdssubgraph, cdssubgraph_nodes_map_cdsgraph;

struct cdsSubGraph {
    VexNode vexs[Max_cdsSubgraph_VertexNum];
    int vexnum;
    int arcnum;
};


void FindcdsContigs (cdsSubGraph &G);
void InsertcdsArc (cdsSubGraph &G, int i, int j);
void DFScdsContigs (cdsSubGraph &G, int v, bool cdssubgraphvisited[], int path[], int depth);
void PrintcdsContigs (cdsSubGraph &G, int path[], int length);

void InsertcdsArc (cdsSubGraph &G, int i, int j) {
    ArcNode *p;
    p=new ArcNode;
    p->adjvex=j;
    p->nextarc=G.vexs[i].firstarc;
    G.vexs[i].firstarc=p;
    G.arcnum++;
        //cout << G.arcnum <<endl;
}
void FindcdsContigs (cdsSubGraph &G) {
    int path[Origin_cdssubgraph_vertics_number];
    memset(cdssubgraphvisited, false, sizeof(cdssubgraphvisited));
    for (int i = 0; i < Origin_cdssubgraph_vertics_number; i++) {
        if(!cdssubgraphvisited[i] && G.vexs[i].indegree==0) {
            cdssubgraphvisited[i]=true;
            path[0]=i;
            DFScdsContigs(G, i, cdssubgraphvisited, path, 1);
        }
    }
}
void DFScdsContigs (cdsSubGraph &G, int v, bool cdssubgraphvisited[], int path[], int depth) {
    for (ArcNode *arc=G.vexs[v].firstarc; arc!=NULL; arc=arc->nextarc) {
        if(G.vexs[arc->adjvex].outdegree==0){
            path[depth]=arc->adjvex;
            PrintcdsContigs (G, path, depth+1);
        }
        if (!cdssubgraphvisited[arc->adjvex]) {
            cdssubgraphvisited[arc->adjvex]=true;
            path[depth]=arc->adjvex;
            DFScdsContigs(G, arc->adjvex, cdssubgraphvisited, path, depth+1);
        }
    }
}
void PrintcdsContigs (cdsSubGraph &G, int path[], int length) {
    vector<int> path_temp;
    for(int i=length-1; i>=0; i--) {
        path_temp.push_back(path[i]);
        if(i!=length-1 && G.vexs[path[i]].outdegree==0)
            break;
    }
    reverse(path_temp.begin(), path_temp.end());
    cdsFragement_paths.push_back(path_temp);
}


#endif /* CDSAssemblySubgraph_h */
